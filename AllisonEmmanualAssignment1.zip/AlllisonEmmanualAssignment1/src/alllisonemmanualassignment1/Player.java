/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alllisonemmanualassignment1;

/**
 *
 * @author Emmanual Allison
 */
public class Player {
    
//Fields
    private String name;
    private int balance;
    private int betAmount;
    private int guess;
    private int guess2;
    public int INITIAL_BALANCE = 500;
    
/**
* Constructor
* @param name - Name of the player
*/
    public Player(String name) {
        this.name = name;
        this.balance = INITIAL_BALANCE;
    }
    
/**
 * Gets the name of the player
 * @return name - A String variable
 */
    public String getName() {
        return name;
    }
/**
 * Gets the guess of the second die (Used in Hard Mode)
 * @return guess2 - An int variable
 */
    public int getGuess2() {
        return guess2;
    }
    
/**
 * Sets the guess of the second die (Used in Hard Mode)
 * @param guess2 - An int variable
 */
    public void setGuess2(int guess2) {
        this.guess2 = guess2;
    }

/**
 * Gets the player's balance.
 * @return balance - An int variable
 */
    public int getBalance() {
        return balance;
    }
    
/**
 * Sets the players balance.
 * @param balance - An int variable
 */
    public void setBalance(int balance) {
        this.balance = balance;
    }
/**
 * Gets the betAmount.
 * @return betAmount - An int variable
 */
    public int getBetAmount() {
        return betAmount;
    }

/**
 * Sets the bet amount.
 * @param betAmount - An int variable
 */    
    public void setBetAmount(int betAmount) {
        this.betAmount = betAmount;
    }

/**
 * Gets the guess of the player (The only guess used
 * in easy mode)
 * @return guess - An int variable
 */
    public int getGuess() {
        return guess;
    }

/**
 * Sets the guess of the player (The only guess used
 * in easy mode)
 * @param guess - An int variable
 */
    public void setGuess(int guess) {
        this.guess = guess;
    }
    
}
