/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alllisonemmanualassignment1;

/**
 *
 * @author Emmanual Allison
 */
public class Start {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        //Displays the Title of the program
        System.out.println("Welcome to the Dice Game!");
        DiceGame dg = new DiceGame(); //Creates a new DiceGame object
        int round = 1;
        
        //Prints the round header, loops until the game is over
        while(!dg.isGameOver()) {
            System.out.println("***********************");
            System.out.println(" ROUND " + round);
            System.out.println("***********************");
            System.out.println();
            dg.playGame();
            round++;
        }
        
        //Displays the game over message and every players' final balance
        System.out.println("Game is over. Everyone's balance is below: ");
        for(int i = 0; i < dg.getNumPlayers(); i++) {
        System.out.println(dg.getPlayers()[i].getName() + ": $" +
        dg.getPlayers()[i].getBalance());
}
    }
    
}
