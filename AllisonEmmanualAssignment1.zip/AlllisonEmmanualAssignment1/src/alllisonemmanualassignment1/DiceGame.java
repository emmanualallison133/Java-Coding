/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alllisonemmanualassignment1;

//Imports packages in Java to be used by the program
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Random;

/**
 *
 * @author Emmanual Allison
 */
public class DiceGame {
    
//Fields
    private int numPlayers;
    private Player[] players;
    private int pot;
    private boolean gameOver;
    private boolean hardMode;
    
/**
 * Constructor, calls the setUpGame() method
 */
    public DiceGame() {
        setUpGame();
    }

/**
 * Gets the players array field
 * @return players The array that holds an array of Player objects.
 */
    public Player[] getPlayers() {
        return players;
    }
    
/**
 * Gets the numPlayers field
 * @return numPlayers, the number of players the game
 */
    public int getNumPlayers() {
        return numPlayers;
    }
/**
 *  Allows the user to select the game mode, 
 *  enter the number of people who are going to play
 *  (used to determine the size of the players array), 
 *  and enter the names of the players, which creates a
 *  new instance of the Player class to access.
 */
    public void setUpGame(){
        
        Scanner input = new Scanner(System.in); //Allows keyboard inputs
        int modeSelect; // Represents the mode to be played in
        
        System.out.println("What is the mode of the game?");
        System.out.println("1. Easy Mode");
        System.out.println("2. Hard Mode");
        modeSelect = input.nextInt(); 
        
        // If 2 is entered at the mode select, 
        // hard mode is activated
        if(modeSelect == 2){
            hardMode = true;
        }
        
        //Asks how many players are going to play the game
        System.out.println("How many people are going to play?");
        // Holds the number of players entered
        numPlayers = input.nextInt(); 

        System.out.println("");
        
        //Assign the players field array length to the number of 
        //players entered.
        players = new Player[numPlayers];
        
        //Asks what the first player's name is.
        System.out.println("What is the first player's name");
        
        //Creates a new instance of a Player class and 
        //assigns it to the first index of the players array
        players[0] = new Player(input.next());
        input.nextLine();
        
        //Creates a new instance of a Player class for every  
        //index after the first and assigns it to the 
        //appropriate index of the players array
        for (int i = 1; i < numPlayers; i++){
            System.out.println("What is the next player's name");
            players[i] = new Player(input.next());
        }
        
        //Calls the displayRules method
        displayRules();
    }
    
/**
 * Checks if the game is over.
 * @return gameOver, a boolean variable
 */
    public boolean isGameOver() {
        return gameOver;
    }

/**
 * Displays the rules of the game. Displays a different
 * set of rules if the game is played on hard mode.
 */
    public void displayRules(){
        //Displays the rules of Easy Mode
        if(hardMode == false){
            System.out.println("");
            System.out.println("RULES!");
            System.out.println("Each player places a bet and chooses a number between 2 and 12. ");
            System.out.println("The total of all the bets forms a \"pot\".");
            System.out.println("Then two die are rolled.");
            System.out.println("If one of the player's bet is correct, they win the entire pot.");
            System.out.println("If more than one players' bets are correct, the one who bet the most wins ");
            System.out.println("the entire pot.");
            System.out.println("If there is a tie, they split the pot.");
            System.out.println("The game is over if one of the players runs out of money.");
            System.out.println("");
        }
        
        //Displays the rules of Hard Mode
        if (hardMode == true){
            System.out.println("");
            System.out.println("RULES OF HARD MODE!!!");
            System.out.println("Each player places a bet and guesses on two numbers between 1 and 6. ");
            System.out.println("The total of all the bets forms a \"pot\".");
            System.out.println("Then two die are rolled.");
            System.out.println("If one of the player's bet is correct, they win the entire pot.");
            System.out.println("If more than one players' bets are correct, the one who bet the most wins ");
            System.out.println("the entire pot.");
            System.out.println("If there is a tie, they split the pot.");
            System.out.println("The game is over if one of the players runs out of money.");
            System.out.println("");
        }
    }
    
/**
 * Calls the playTurn method for each Player class,
 * adds the player's bet amount to the pot, displays the 
 * pot amount, emulates the rolling of two die by generating
 * numbers between two and twelve (or two random 
 * numbers between 1 and 6 in hard mode), calls the appropriate
 * checkWinner method to see who won and sets gameOver to true if
 * any of the player's balance is now equal to zero
 */
    public void playGame(){
        
        int outcome; //Stores the added numbers of the two random numbers or "die" in Easy Mode
        int hardOutcome1; //Stores the number of the first die in hard mode
        int hardOutcome2; //Stores the number of the second die in hard mode
        Random r = new Random(); //Allow use of the Random package
                
        //Calls the playTurn method for each Player class
        //in the players field and adds their bet amount to 
        //the pot 
        for(int i = 0; i < numPlayers; i++){
            playTurn(players[i]);
            pot += players[i].getBetAmount();
        }
        
        //Diplays how much is in the pot
        System.out.println("There is $" + pot +" in the pot");
        
        //Executes if the game is in Easy Mode
        if(hardMode == false){
            do
                //Emulates the rolling of two dice generating two random
                //numbers and adding them together
                outcome = r.nextInt(6) + r.nextInt(6);
            
          /* 
           * Because nextInt() generates numbers between 0 and 6
           * it is possible to have the outcome equal 1 or 0. The
           * do - while loop ensures that if this occurs, the numbers
           * will be added and rolled again until the number is between 2 and 12
           */
            while(outcome == 1 || outcome == 0); 
            
           //Prints the outcome
            System.out.println("The outcome is " + outcome + " for this round");
            
           //Calls the checkWinner method
            checkWinner(outcome);
        }
        
        //Executes if the game is in Hard Mode
        else if(hardMode == true){
            
            do
                //Assigns a random number between 1 and 6 to hardOutcome1
                hardOutcome1 = r.nextInt(6);
            while (hardOutcome1 == 0);
                
            do
                //Assigns a random number between 1 and 6 to hardOutcome1
                hardOutcome2 = r.nextInt(6);
            while (hardOutcome2 == 0);
            
            //Diplays the outcomes of the two random numbers or die
            System.out.println("The outcomes are " + hardOutcome1 + 
                    " and " + hardOutcome2 + " for this round");

            //Calls the checkWinner method that accept two int arguments
            checkWinner(hardOutcome1, hardOutcome2);

        }
           
        //Checks if any players' balance is at 
        //0, if so the game is over.
        for (int i = 0; i < players.length; i++) {
            if (players[i].getBalance() == 0) {
                gameOver = true;
            }
        }
        
    }

/**
 * Tells the player their balance and asks
 * them to enter the amount they want to bet.
 * Does not allow the players bet to 
 * exceed their available funds or to enter a 
 * value outside the range of 2 and 12 (1 and 6 in hard mode).
 * @param player The current player in the turn's Player class
 */
    public void playTurn(Player player){
        
        //Allows keyboard inputs
        Scanner input = new Scanner(System.in);
        
        //Displays the current Player's name, their balance,
        //and asks how much they wnat to bet.
        System.out.println(player.getName() + ", you have $" + player.getBalance() 
                + " left, how much are you going to bet?");
        
        System.out.print("$");
        
        //Set the player's entered bet amount 
        player.setBetAmount(input.nextInt());
        
        //Displays an error message when the player's 
        //bet balance exceeds available funds and allows the 
        //user to enter another bet amount
        while (player.getBetAmount() > player.getBalance()){
            System.out.println("Bet balance exceeds available funds");
            System.out.print("Please try again: $");
            player.setBetAmount(input.nextInt());
        }
        
        //Subtracts the players bet amount from their balance
        player.setBalance(player.getBalance()- player.getBetAmount());
        
        //Allows the play to enter their guess in Easy Mode
        if(hardMode == false){
            System.out.println("Which number between 2 and 12 are you betting on?");
            player.setGuess(input.nextInt()); //Sets the players guess
            
            //Displays an error message when the player's guess is outside
            //the range of 2 and 12 and allows them to enter a valid guess.
            while (player.getGuess() < 2 || player.getGuess() > 12){
                System.out.println(player.getGuess() + " is not a valid guess");
                System.out.println("Please enter your guess again:");
                player.setGuess(input.nextInt());
            }
        }
        
        //Allows the play to enter two guesses in Hard Mode
        else if(hardMode == true){
            System.out.println("Which number between 1 and 6 are you betting on for "
                    + " the first die?" );
            player.setGuess(input.nextInt());
            
            //Displays an error message when the player's first guess 
            //is outside the range of 1 and 6 and allows them 
            //to enter a valid guess.
            while (player.getGuess() > 6 || player.getGuess() < 1){
                System.out.println("Your first guess must be be between 1 and 6");
                System.out.println("Please try again:");
                player.setGuess(input.nextInt());
            }
            
            System.out.println("Which number between 1 and 6 are you betting on"
                    + " for the second die?");
            player.setGuess2(input.nextInt());
            
            //Displays an error message when the player's second guess 
            //is outside the range of 1 and 6 and allows them 
            //to enter a valid guess.
            while (player.getGuess2() > 6 || player.getGuess2() < 1){
                System.out.println("Your second guess must be be between 1 and 6");
                System.out.println("Please try again:");
                player.setGuess2(input.nextInt());
            }
            
        }
       
    }   
    
/**
 * Finds if any player correctly guessed the outcome
 * and updates each player’s balance and the 
 * balance of the pot accordingly (used in easy mode)
 * @param outcome The added number of the two random numbers/die.
 */
    public void checkWinner(int outcome){
        //Stores an ArrayList of Player classes who correctly guessed the outcome
        ArrayList<Player> winners = new ArrayList<Player>(); 
        
        //Stores an ArrayList of Player classes who correctly guessed the outcome
        //and bet the same amount
        ArrayList<Player> tiedWinners = new ArrayList<Player>();
        
        int highestBet = 0; //Stores the highest betted amount among the players
        int earned = pot;   //Show how much has been earned by the winning players
        
        //Adds the Player classes who correctly guessed the outcome to
        //winners ArrayList
        for (Player player : players) {
            if (player.getGuess() == outcome) {
                winners.add(player);
            }
        }
        
        //Executes if no one correctly guessed the outcome
        if (winners.isEmpty()){
            System.out.println("No one wins...");
        }
        
        //Executes if only one person correctly guessed the outcome
        else if(winners.size() == 1){
            earned = pot;
            winners.get(0).setBalance(winners.get(0).getBalance() + pot);
            
            //Resets the pot to zero
            pot = 0;
        }
        
        //Executes if multiple person correctly guessed the outcome
        else if (winners.size() > 1){
            
            //Set the first Players as the highest for the "for" loop
            highestBet = winners.get(0).getBetAmount();
            
            //Finds the highest bet amount amongst the players
            //who correctly guessed the outcome
            for(int i = 1; i < winners.size(); i++){
                if (winners.get(i).getBetAmount() > highestBet)
                    highestBet = winners.get(i).getBetAmount();
                
                //Add the players who correctly guessed the outcome
                //and bet the same highest amount to the tiedWinners ArrayList
                if (winners.get(i).getBetAmount() == highestBet)
                    tiedWinners.add(winners.get(i));
            }
            
            //Evenly splits the pot in and add the earned amount to each of
            //the tied winners's balance
            for (int i = 0; i < tiedWinners.size(); i++){
                    earned = pot/tiedWinners.size();
                    tiedWinners.get(i).setBalance(tiedWinners.get(i).getBalance() + earned);
            }
            
            //Resets the pot to zero
            pot = 0;
        }
        
        //Displays who lost or won and how much they lost or won.
        for (Player player : players) {
            if (player.getBetAmount() < highestBet || player.getGuess() != outcome) {
                System.out.println(player.getName() + " lost $" + player.getBetAmount() + " this round...");
            } else {
                System.out.println(player.getName() + " won $" + earned + " this round!");
            }
        }
            
        }
/**
*  Finds if any player correctly guessed the both outcomes
 * and updates each player’s balance and the 
 * balance of the pot accordingly (used in hard mode)
 * @param outcome1 The outcome of the first random number
 * @param outcome2 The outcome of the second random number
 */
    public void checkWinner (int outcome1, int outcome2){
        //Stores an ArrayList of Player classes who correctly guessed the outcome
        ArrayList<Player> winners = new ArrayList<Player>(); 
        
        //Stores an ArrayList of Player classes who correctly guessed the outcome
        //and bet the same amount
        ArrayList<Player> tiedWinners = new ArrayList<Player>();
        
        int highestBet = 0; //Stores the highest betted amount among the players
        int earned = pot;   //Show how much has been earned by the winning players
        
        //Adds a player to the winners ArrayList if they correctly guessed both outcomes
        for (int i = 0; i < players.length; i++){
            if((players[i].getGuess() == outcome1 || players[i].getGuess() == outcome2) 
                    && (players[i].getGuess2() == outcome1 || players[i].getGuess2() == outcome2))
                winners.add(players[i]);
            }
        
        //Executes if no one correctly guessed the outcome
        if(winners.isEmpty()){
            System.out.println("No one wins...");
            for (int i = 0; i < players.length; i++) 
                System.out.println(players[i].getName() + " lost $" + players[i].getBetAmount() + " this round...");
                 
            }
        
        //Executes if only one person correctly guessed both outcome
        if (winners.size() == 1){
            winners.get(0).setBalance(winners.get(0).getBalance() + pot);
            
            //Displays who lost or won and how much they lost or won.
            for (int i = 0; i < players.length; i++) {
                if (winners.contains(players[i])){
                    System.out.println(players[i].getName() + " won $" + earned + " this round!");
                } else {
                    System.out.println(players[i].getName() + " lost $" + players[i].getBetAmount() + " this round...");
                    }
            }
            
            //Resets the pot to zero
            pot = 0;
        }
        
        //Executes if multiple person correctly guessed both outcomes
        if (winners.size() > 1){
            
            //Sets the the player at the being of the winners ArrayList as
            //the highest bet
            highestBet = winners.get(0).getBetAmount();
            
            //Finds which of the winners bet the highest bet
            for(int i = 1; i < winners.size(); i++){
                if (winners.get(i).getBetAmount() > highestBet)
                    highestBet = winners.get(i).getBetAmount();
            }    
            
            //Adds the winners who bet the highest 
            //bet to the tiedWinners ArrayList
            for(int i = 0; i < winners.size(); i++){
                if (winners.get(i).getBetAmount() == highestBet)
                    tiedWinners.add(winners.get(i));
            }
            
            //Splits the pot by the number of tiedWinners and 
            //adds the earned amount by
            for (int i = 0; i < tiedWinners.size(); i++){
                    earned = pot/tiedWinners.size();
                    tiedWinners.get(i).setBalance(tiedWinners.get(i).getBalance() + earned);
                }     
            
            //Displays who lost or won and how much they lost or won.
            for (int i = 0; i < players.length; i++) {
                if (tiedWinners.contains(players[i])){
                    System.out.println(players[i].getName() + " won $" + earned + " this round!");
                } else {
                    System.out.println(players[i].getName() + " lost $" + players[i].getBetAmount() + " this round...");
                    }
            }
            
            //Resets the pot to zero
            pot = 0;
        }            
    }
}