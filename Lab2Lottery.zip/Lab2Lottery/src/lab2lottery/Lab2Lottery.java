/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2lottery;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Emmanual Allison
 */
public class Lab2Lottery {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        displayRules();
        
        int[] winningNumbers = generateWinningNumbers();
        int[] playerPicks = getPlayerPicks();
        
        System.out.print("Winning ticket is: ");
        
        for(int i = 0; i < winningNumbers.length; i++){
            System.out.print(winningNumbers[i] + " ");
        }
        System.out.println();
        
        System.out.print("Player's pick is: ");
        for(int i = 0; i < playerPicks.length; i++){
            System.out.print(playerPicks[i] + " ");
        }
        System.out.println();
        
        int matching = matchNumbers(winningNumbers, playerPicks);
        
        System.out.println("Number of matching digits: " + matching);
        System.out.println();
        
        calculatePrize(matching);
        calculatePrize(winningNumbers, playerPicks);
    }
    /**
     * Displays the rules of the program.
     */
    public static void displayRules(){
        System.out.println("Welcome to the Fantasy Five Lottery.");
        System.out.println("Each player picks 5 numbers between 0-35.");
        System.out.println("Drawing are held Monday through Saturday at 5:00 pm.");
        System.out.println("Best of luck in your game!");
    }
    /**
     * Generates a list of five random integer numbers 
     * between the numbers of 0 and 35 to use for the 
     * winning lottery numbers.
     * @return An array of 5 random integers.
     */
    public static int[] generateWinningNumbers(){
        int[] randomNums = new int[5];
        
        Random rnd = new Random();
        
        for (int i = 0; i < randomNums.length; i++){
            randomNums[i] = rnd.nextInt(35);
        }
        
        return randomNums;
    }
    /**
     * Allows the user to enter five integers numbers.
     * Displays an error message if an entered number is 
     * outside the range of 0 and 35, but allows the user to 
     * enter another value.
     * @return An array of five integers entered by the user.
     */
    public static int[] getPlayerPicks(){
        int[] players = new int[5];
        
        Scanner scnr = new Scanner(System.in);
        
        System.out.println("Please enter five integers between 0 and 35: ");
        
        for(int i = 0; i < players.length; i++){
            players[i] = scnr.nextInt();
            
            while (players[i] < 0 || players[i] > 35){
                System.out.println(players[i] + " is not a valid number. "
                + "Please enter another number.");
                
                players[i] = scnr.nextInt();
                
            }
        }
        
        return players;
    }
    
    /**
     * Checks each number in the random and player lists
     * to see if they match in value and position.
     * @param win; an array of the winning lottery numbers.
     * @param play; an array of the user's lottery numbers.
     * @return matchingNums; the number of matches in each list.
     */
    public static int matchNumbers(int[] win, int[] play){
        int matchingNums = 0;
        
        for (int i = 0; i < play.length || i < win.length; i++){
            if (win[i] == play[i]){
                matchingNums++;
            }
        }
        
        return matchingNums;
    }
    
    /**
     * Displays the prize message based on the number of matches from
     * winning and players numbers lists.
     * @param matches; number of matches from the winning and player's
     * numbers lists. 
     */
    public static void calculatePrize(int matches){
        switch (matches){
            case 0:
            case 1:
                System.out.println("Too bad, you won $0...");
                break;
            case 2:
                System.out.println("Congratulations! You won $10!");
                break;
            case 3:
                System.out.println("Congratulations! You won $50!");
                break;
            case 4:
                System.out.println("Congratulations! You won $250!");
                break;
            case 5:
                System.out.println("Congratulations! You got the jackpot!");
                break;
            }
        }
    
    /**
     * Calls other methods to calculate the number of matches and 
     * display the prize message. 
     * @param winNums; an array of the winning lottery numbers.
     * @param playNums; an array of the player's lottery numbers.
     */
    public static void calculatePrize(int[] winNums, int[]playNums){
        int match = matchNumbers(winNums, playNums);
        calculatePrize(match);
    }
}
