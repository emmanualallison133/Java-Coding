/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package turtletest; 
import BookClasses.*;

/**
 *
 * @author Emmanual Allison
 */
public class TurtleTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        World w = new World();
        Turtle t = new Turtle(w);
        
        t.penDown();
        t.turn(-30);
        t.forward();
        t.turn(-150);
        t.forward();
        t.turn(-140);
        t.forward();
        t.turn(-145);
        t.forward();
        t.turn(-140);
        t.forward();
    }
    
}
