/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package phonebook;

import java.util.Scanner;

/**
 *
 * @author lcao2
 */
public class Start {
    public static void main(String[] args) {
        
        Scanner scnr = new Scanner(System.in);
        
        PhoneBook book = new PhoneBook();
        initialize(book);
        
        System.out.println("Welcome to the Yellow Book Digital Phonebook!");
        displayMenu();
        String choice = scnr.nextLine();
        
        while (choice != "0"){
            switch (choice){
                case "1":
                    System.out.println("");
                    System.out.print("Please enter your name: ");
                    String name = scnr.nextLine();
                    System.out.print("Please enter you phone number in ###-###-#### format: ");
                    String phone = scnr.nextLine();
                    
                    book.addEntry(name, phone);
                    
                    System.out.println("Entry added!");
                    
                    displayMenu();
                    choice = scnr.nextLine();
                    break;
                    
                case "2":
                    System.out.println("");
                    System.out.print("Please enter the name you made the entry with (This is case-sensitive!): ");
                    name = scnr.nextLine();
                    System.out.print("Please enter the new phone number within ###-###-#### format: ");
                    phone = scnr.nextLine();
                    
                    book.editEntry(name, phone);
                    
                    displayMenu();
                    choice = scnr.nextLine();
                    break;  
                    
                case "3":
                    System.out.println("");
                    System.out.println("Please enter the name of the person you want to find the phone number to\n"
                            + "(This is case-sensitive!):");
                    name = scnr.nextLine();
                    
                    if (book.searchPhoneNumber(name) != null){
                        System.out.println("");
                        System.out.println("The phone number of " + name + " is " + book.searchPhoneNumber(name));
                    }
                    else{
                        System.out.println("");
                        System.out.println("The name " + name + " was not found in the phonebook..."); 
                    }
                    displayMenu();
                    choice = scnr.nextLine();
                    break;
                    
                case "4":
                    System.out.println("Please enter the name of the person you wish to remove from the phonebook \n"
                            + "(This is case-sensitive!): ");
                    name = scnr.nextLine();
                    
                    book.removeEntry(name);
                    
                    displayMenu();
                    choice = scnr.nextLine();
                    break; 
                    
                case "5":
                    book.printBook();
                    displayMenu();
                    choice = scnr.nextLine();
                    break;
                case "0":
                    choice = "0";
                    System.out.println("Exiting Program...");
                    break;  
                    
                default:
                    System.out.println(choice + " is not a valid entry. Please try again");
                    choice = scnr.nextLine();
                    break;
            }
        }
    }
    
    public static void initialize(PhoneBook book) {
        book.addEntry("Roxanne Hughes", "443-555-2864");
        book.addEntry("Juan Alberto Jr.", "410-555-9385");
        book.addEntry("Rachel Phillips", "310-555-6610");
    
    }

    private static void displayMenu() {
                System.out.println("");
                System.out.println("Please enter your choice");
                System.out.println("1. Add an entry");
                System.out.println("2. Edit an entry");
                System.out.println("3. Look up phone number");
                System.out.println("4. Remove an entry");
                System.out.println("5. Print out phone book");
                System.out.println("0. Exit");
        } 

}