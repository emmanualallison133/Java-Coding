/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DrawingProgram;

import java.awt.Color;
import java.awt.Graphics2D;

/**
 *
 * @author Emmanual Allison
 */
public class Oval extends Shape{

    private int width;
    private int height;

    public Oval(int x, int y, Color color, int width, int height) {
        super(x, y, color);
        this.width = width;
        this.height = height;
    }

    @Override
    public void draw(Graphics2D g) {
        g.setColor(super.getColor());
        g.drawOval(super.getX(), super.getY(), width, height);
    }

    @Override
    public double getArea() {
        return 0.25 * width * height * Math.PI;
    }
    
}
