package DrawingProgram;

import java.awt.*;
import static java.awt.Color.*;
import java.util.ArrayList;
import java.util.Collections;
import javax.swing.*;


/**
 *
 * @author lcao2
 */
public class DrawingWindow extends JPanel {

    ArrayList<Shape> shapes = new ArrayList<Shape>();

    public DrawingWindow() {
        this.setBackground(Color.WHITE);
        //add different types of shapes in the ArrayList
        shapes.add(new Rectangle(10, 10, Color.BLACK, 100, 200));
        shapes.add(new Triangle(40, 40, Color.RED, 30, 40));
        shapes.add(new Oval(20, 20, Color.BLUE, 10, 20));
        shapes.add(new Square(256, 349, Color.ORANGE, 299));
        shapes.add(new Circle(25, 99, Color.MAGENTA, 69));
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        
        for (Shape s : shapes) {
            s.draw(g2d);
        }

    }

    public static void main(String[] args) {
        JFrame drawingFrame = new JFrame();
        drawingFrame.setSize(1000, 1000);
        drawingFrame.setTitle("Drawing Window");
        drawingFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        DrawingWindow window = new DrawingWindow();
        drawingFrame.add(window);
        drawingFrame.setVisible(true);

        System.out.println("Sorting shapes by area");
        Collections.sort(window.shapes);
        for (Shape s : window.shapes) {
            System.out.println("Area of " + s.getClass().getSimpleName() + " is: " + s.getArea());
        }
        
    }

}
