/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DrawingProgram;

import java.awt.Color;
import java.awt.Graphics2D;

/**
 *
 * @author Emmanual Allison
 */
public class Triangle extends Shape{
    private int base;
    private int height;
    
    public Triangle(int x, int y, Color color, int base, int height) {
        super(x, y, color);
        this.base = base;
        this.height = height;
    }

    @Override
    public void draw(Graphics2D g) {
        int[] xPoints = new int[3];
        int[] yPoints = new int[3];
        
        xPoints[0] = super.getX();
        xPoints[1] = super.getX()+ base;
        xPoints[2] = super.getX()+ height;
        
        yPoints[0] = super.getY();
        yPoints[1] = super.getY() + base;
        xPoints[2] = super.getY()+ height;
        
        g.setColor(super.getColor());
        
        g.drawPolygon(xPoints, yPoints, 3);
    }

    @Override
    public double getArea() {
        return 0.5 * base * height;
    }
    
}
