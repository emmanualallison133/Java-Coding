/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DrawingProgram;

import java.awt.Color;
import java.awt.Graphics2D;

/**
 *
 * @author Emmanual Allison
 */
public class Rectangle extends Shape {
    private int width;
    private int length;

    public Rectangle(int x, int y, Color color, int width, int length) {
        super(x, y, color);
        this.width = width;
        this.length = length;
    }

    @Override
    public void draw(Graphics2D g) {
        g.setColor(super.getColor());
        g.drawRect(width, length, width, length);
    }

    @Override
    public double getArea() {
        return length * width;
    }
    
}
