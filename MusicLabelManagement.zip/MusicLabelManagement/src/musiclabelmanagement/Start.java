/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package musiclabelmanagement;

/**
 *
 * @author Emmanual Allison
 */
public class Start {
    
    /**
     * The first method called, which creates a
     * new MusicLabelManagement object.
     * 
     * @param args 
     */
    public static void main(String[] args) {
        MusicLabelManagement Label = new MusicLabelManagement(); 
    }
    
}
