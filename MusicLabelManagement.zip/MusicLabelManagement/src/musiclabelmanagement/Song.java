/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package musiclabelmanagement;
import BookClasses.*;
/**
 *
 * @author Emmanual Allison
 */
public class Song {
    private Sound song;
    private String title;
    private String writer;
    private MusicGroup group;
    private float royalty;
    private float songPrice;
    private int numPlays;
    private int numPurchases;
    private float earning;
    
    /**
     * Accepts the song, title, the song's writer,
     * the group who created the song, the 
     * royalty cost, the song's price, and initializes them
     * to be used in the class' methods.
     * 
     * @param song
     * @param title
     * @param writer
     * @param group
     * @param royalty
     * @param songPrice 
     */
    public Song(Sound song, String title, String writer, MusicGroup group, float royalty, float songPrice) {
        this.song = song;
        this.title = title;
        this.writer = writer;
        this.group = group;
        this.royalty = royalty;
        this.songPrice = songPrice;
        
        this.numPlays = 0;
        this.numPurchases = 0;
        this.earning = 0.0f;
    }
    
/**
 * Gets the song that is currently playing
 * @return song
*/
    public Sound getSong() {
        return song;
    }
/**
 * Gets the writer of the song currently
 * playing.
 * 
 * @return writer
 */
    public String getWriter() {
        return writer;
    }
/**
 * Gets the group that peformed the song.
 * 
 * @return group
 */
    public MusicGroup getGroup() {
        return group;
    }
/**
 * Gets the total earnings .
 * @return earning
 */
    public float getEarning() {
        return earning;
    }
/**
 * Increments the number of purchases after the
 * user decides to makes a purchase and adds
 * the current song's price to the total of earnings.
 */
    public void purchase(){
        numPurchases =+ 1;
        earning =+ songPrice;
    }
/**
 * Plays the current song, increments the number of times
 * a song has been played and adds the cost of royalties 
 * to the total earnings each time a song is played.
 */   
    public void play(){
        song.blockingPlay();
        numPlays =+ 1;
        earning =+ royalty;
    }
    
}
