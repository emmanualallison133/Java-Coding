/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package musiclabelmanagement;
import BookClasses.*;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;
/**
 *
 * @author Emmanual Allison
 */
public class MusicLabelManagement {
    
    private ArrayList<MusicGroup> groups = new ArrayList<MusicGroup>();
    private ArrayList<Album> albums = new ArrayList<Album>();
    private ArrayList<Song> songs = new ArrayList<Song>();
    
    /**
     *  Constructor
     */
    public MusicLabelManagement() {
        // add a bunch of music groups, songs and albums 
        initialize();
        
        // get interactive with the user, playing songs and letting them buy them
        Scanner s = new Scanner(System.in);
        // type a 0 to stop playing songs
        try {
            System.out.println("Jukebox starting. Type a '1' to play a song. Type a '0' to end.");
            while (s.nextInt() != 0) {    
                jukebox();
                System.out.println("Type a '1' to play another song. Type a '0' to end.");
            }
        } catch (InputMismatchException e) {
            System.out.println("Sorry, but you can only type integers. Jukebox ending.");
        }

        // when done with interactive portion, 
        // iterate through the record label's groups, printing out revenues of each
        for (MusicGroup group : groups) {
            System.out.println(group.getGroupName() + " has earned $" + group.getEarnings() + " so far.");
        }


    }
    
/**
 * Adds music groups, songs and albums to their respective classes.
 */    
    public void initialize(){
        FileChooser.setMediaPath("C:\\Users\\Emmanual Allison\\Documents\\NetBeansProjects\\mediasources\\");
    
        // create the first group (Beatles)
        MusicGroup beatles = new MusicGroup("Beatles");
        beatles.addMember("Paul McCartney");
        beatles.addMember("Ringo Star");
        beatles.addMember("John Lennon");
        beatles.addMember("George Harrison");
        // add to list of record label's groups
        groups.add(beatles);
        // create new album
	Album album1 = new Album("Greatest Hits", "Random Person", 9.99f, beatles);

        Song song1 = new Song(new Sound(FileChooser.getMediaPath("CantBuyMeLove.wav")), "Can't Buy Me Love", "random dude", beatles, 0.01f, 0.99f);
        beatles.addSong(song1);
        songs.add(song1);
        album1.addSong(song1);
        Song song2 = new Song(new Sound(FileChooser.getMediaPath("PennyLane.wav")), "Penny Lane", "random dude", beatles, 0.01f, 0.99f);
        beatles.addSong(song2);
        songs.add(song2);
        album1.addSong(song2);
        Song song3 = new Song(new Sound(FileChooser.getMediaPath("YellowSubmarine.wav")), "Yellow Submarine", "random dude", beatles, 0.01f, 0.99f);
        beatles.addSong(song3);
        songs.add(song3);
        album1.addSong(song3);
        Song song4 = new Song(new Sound(FileChooser.getMediaPath("PaperbackWriter.wav")), "Paperback Writer", "random dude", beatles, 0.01f, 0.99f);
        beatles.addSong(song4);
        songs.add(song4);
        album1.addSong(song4);
        Song song5 = new Song(new Sound(FileChooser.getMediaPath("HardDaysNight.wav")), "Hard Day's Night", "random dude", beatles, 0.01f, 0.99f);
        beatles.addSong(song5);
        album1.addSong(song5);
        songs.add(song5);
        
        
        // add this album to beatles list of albums
        beatles.addAlbum(album1);
        // add this album to the record label's list of albums
        albums.add(album1);

    }
/**
 * Selects a random song to play from the list of songs, 
 * and asks the user if they would like to purchase the song.
 */
    public void jukebox(){
        int index = (int)(Math.random()*songs.size());
        Song song = songs.get(index);
        System.out.println("Playing " + song.getSong() + " by " + song.getGroup() + ", written by: " + song.getWriter());
        song.play();
        System.out.println("Would you like to purchase this song? (Y/N)");
        Scanner sc = new Scanner(System.in);
        char c = sc.next().charAt(0);
        if (c == 'Y' || c == 'y') {
            song.purchase();
            System.out.println("Thank-you for your purchase!");
        } 

    }
}
    
