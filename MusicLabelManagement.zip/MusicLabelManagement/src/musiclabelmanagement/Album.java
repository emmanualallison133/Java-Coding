/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package musiclabelmanagement;
import BookClasses.*;
import java.util.ArrayList;
/**
 *
 * @author Emmanual Allison
 */
public class Album {
    private String title;
    private ArrayList<Song> songs = new ArrayList<Song>();
    private String producer;
    private float albumPrice;
    private MusicGroup group;
    private float earning;
    private int numPurchases;
    
    /**
     * Takes the current song's title, its producer, 
     * the album's price, and the music group's name, then
     * assigns them to the appropriate field. 
     * Also initializes the earning and numPurchases field to
     * zero.
     * 
     * @param title
     * @param producer
     * @param albumPrice
     * @param group 
     */
    public Album(String title, String producer, float albumPrice, MusicGroup group) {
        this.title = title;
        this.producer = producer;
        this.albumPrice = albumPrice;
        this.group = group;
        
        earning = 0.0f;
        numPurchases = 0;
    }
    /**
     * Gets the title of the song.
     * 
     * @return title, the title of the song
     */
    public String getTitle() {
        return title;
    }
    /**
     * Gets the producer of the song.
     * 
     * @return producer, the producer of the song.
     */
    public String getProducer() {
        return producer;
    }
    /**
     * Gets the price of the Album.
     * 
     * @return albumPrice, the price of the Album.
     */
    public float getAlbumPrice() {
        return albumPrice;
    }
    
    /**
     * Gets the group who made the song.
     * 
     * @return group, the musical group who made
     * song.
     */
    public MusicGroup getGroup() {
        return group;
    }
    /**
     * Gets the total earnings
     * 
     * @return earning, the total earning.
     */
    public float getEarning() {
        return earning;
    }
    
    /**
     * After the user has decided to make a purchase,
     * increments the number of purchases
     * by one and accumulates the total earnings
     * from the album's price.
     */
    public void purchase(){
        numPurchases =+ 1;
        earning =+ albumPrice;
    }
    
    /**
     * Takes the current song as a parameter
     * and adds it to the songs ArrayList.
     * 
     * @param song 
     */
    public void addSong(Song song){
        songs.add(song);
    }
    
    /**
     * Plays all of the songs in the album in order if "shuffle" is false.
     * If "shuffle" is true, plays all the songs in a random unique order
     * 
     * @param shuffle
     */
    public void playAlbum(boolean shuffle){
        if (!shuffle) {
            for (Song s : songs ) {
                s.play();
            }
        } else {
            // need to shuffle songs, create array of booleans set to false
            boolean[] playedSong = new boolean[songs.size()];
            for (int i = 0; i < songs.size(); i++) {
                playedSong[i] = false;
            }
            // now, keep generating random index of song that hasn't been played
            for (int i = 0; i < songs.size(); i++) {
                int index = -1;
                while (true) {
                    index = (int)(Math.random()*songs.size());
                    if (playedSong[i] == false) break;
                }
                // got index, play song, set boolean flag
                songs.get(index).play();
                playedSong[index] = true;
            }
        }

    }
    
}
