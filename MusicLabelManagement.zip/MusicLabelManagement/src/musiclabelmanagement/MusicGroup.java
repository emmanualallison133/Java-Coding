/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package musiclabelmanagement;
import BookClasses.*;
import java.util.ArrayList;
/**
 *
 * @author Emmanual Allison
 */
public class MusicGroup {
    private String groupName;
    private ArrayList<String> members = new ArrayList<String>();
    private ArrayList<Album> albums = new ArrayList<Album>();
    private ArrayList<Song> songs = new ArrayList<Song>();

    /**
     * Assigns the name of the group to the 
     * group name field
     * @param groupName 
     */
    public MusicGroup(String groupName) {
        this.groupName = groupName;
    }
    
/**
 * Gets the name of the group 
 * who made the song
 * @return groupName;
 */
    public String getGroupName() {
        return groupName;
    }
    
    /**
     * Gets the total number of earnings by
     * accumulating the earnings into a total
     * 
     * @return total
     */
    public float getEarnings(){
        float total = 0.0f;
        
        for(Album s: albums){
            total += s.getEarning();
        }
        
        return total;
    }
    
    /**
     * Adds a group member's name to the
     * members ArrayList.
     * 
     * @param name
     */
    public void addMember(String name){
        members.add(name);
    }
    
    /**
     * Adds an album to the albums ArrayList.
     * 
     * @param album 
     */
    public void addAlbum(Album album){
        albums.add(album);
    }
    
    /**
     * Adds a song to the songs ArrayList
     * 
     * @param song 
     */
    public void addSong(Song song){
        songs.add(song);
    }
}
