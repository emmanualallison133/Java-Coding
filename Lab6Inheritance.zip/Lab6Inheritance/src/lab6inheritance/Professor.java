/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6inheritance;

import java.util.ArrayList;

/**
 *
 * @author Emmanual Allison
 */
public class Professor extends Person {
    
    private String department;
    private double salary;
    private ArrayList<Student> advisees = new ArrayList<Student>();

    public Professor(String name, int id, String department, double salary){
        super(name, id);
        this.department = department;
        this.salary = salary;
    }

    public String getDepartment() {
        return department;
    }

    public double getSalary() {
        return salary;
    }

    public ArrayList<Student> getAdvisees() {
        return advisees;
    }

    public void setDepartment(String dept) {
        this.department = department;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }
    
    public void addAdvisee(Student student){
        advisees.add(student);
    }
    
    public boolean removeAdvisee(String name){  
        
        return advisees.remove(name);

    }
    

    public void display(){
        
        super.display();
        System.out.println("Department:" +  department);
        System.out.println("Salary: $" + salary);
        System.out.println("Advisees:");

        for(Student c : advisees){
            System.out.println(c.getName());
        }
    }
}