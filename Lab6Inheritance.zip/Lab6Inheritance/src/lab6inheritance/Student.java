/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6inheritance;
import java.util.ArrayList;
/**
 *
 * @author Emmanual Allison
 */
public class Student extends Person {
    
    private String major;
    private double gpa;
    private ArrayList<String> enrolledClasses = new ArrayList<String>();
    
    public Student(String name, int id, String major, double gpa){
        super(name, id);
        this.major = major;
        this.gpa = gpa;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public double getGpa() {
        return gpa;
    }

    public void setGpa(double gpa) {
        this.gpa = gpa;
    }

    public ArrayList<String> getEnrolledClasses() {
        return enrolledClasses;
    }

    public void setEnrolledClasses(ArrayList<String> enrolledClasses) {
        this.enrolledClasses = enrolledClasses;
    }
    
    public boolean addClass(String course){
        return enrolledClasses.add(course);
    }
    
    public boolean dropClass(String course){
        return enrolledClasses.remove(course);
    }
    
    @Override
    public void display(){
    
        super.display();
        System.out.println("Major:" + major);
        System.out.println("GPA:" + gpa);
        System.out.println("Enrolled in the following classes:");
        for(int i = 0; i < enrolledClasses.size(); i++)
        System.out.println(enrolledClasses.get(i));
    }
    
    
}
