/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6inheritance;

/**
 *
 * @author Emmanual Allison
 */
public class Lab6Inheritance {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Person p = new Person("Alice", 1000);
        //p.display();
        
        /*System.out.println("");
        
        Student s1 = new Student("Malick", 900, "CS", 3.5);
        s1.addClass("Java Programming");
        s1.addClass("Calculus");
        
        s1.display();
        
        if (s1.dropClass("Spanish"))
            System.out.println("The class has been dropped");
        else
            System.out.println("You are not enrolled in the class");
        
        */
        
        Student s1 = new Student("Malick", 900, "CS", 3.5);
        Student s2 = new Student("Sumukh", 901, "CS", 3.2);
        Student s3 = new Student("Magarita", 902, "CS", 3.0);

        Professor p1 = new Professor("Marlon", 300, "CS", 80000);
        p1.addAdvisee(s3);
        p1.addAdvisee(s2);
        p1.addAdvisee(s1);
        
        p1.display();

        if(p1.removeAdvisee("John"))
            System.out.println("The advisee has been removed");
        else
            System.out.println("The advisee cannot be found in the list");
        
        if(p1.removeAdvisee("Malick"))
            System.out.println("The advisee has been removed");
        else
            System.out.println("The advisee cannot be found in the list");
        
        
    }
    
}
