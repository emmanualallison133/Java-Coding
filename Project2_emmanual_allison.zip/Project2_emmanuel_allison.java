import java.util.Scanner; //Needed for the Scanner class
import java.io.*;         //Needed for the File I/O classes

/*
This program reads the file "Computers.txt" as input for calculations, displaying a 
Recommended Graphics Quality and the highest and lowest performance scores to the user.
**/ 

public class Project2_emmanuel_allison
{
   public static void main(String[] args) throws IOException   //Throws the "IOException" exception type.
   {
      //Opens the "Computer.txt" file
      File file = new File("Computers.txt");  
      
      //Displays an error message if the file is not found and closes the file.
      if(!file.exists())
      {
         System.out.println("The file Computers.txt is not found.");
         System.exit(0);
      }
      
      //Reads the file using the Scanner class
      Scanner inputFile = new Scanner(file);

      //Declares and Intitalizes varibles
      double GPU_speed = 0.00, CPU_speed = 0.00;  
      int ProcessorCores = 0, resolutionChoice = 0;      
      double multiplier = 0.00, performanceScore = 0.00;        
      String Recommended_Graphics_Quality = null;                                  
      String programTitle = "Computer Hardware Graphics Quality Recommendation Tool"; 
      String resolution = null;
      double highestScore = 0,lowestScore = 0;
      boolean firstFile = true;
      
      //Prints "Computer Hardware Graphics Quality Recommendation Tool" at the beginning of the program.
      System.out.println(programTitle);
      
      //Loops processes the lines read through the file until it reaches the end.
       while(inputFile.hasNext())
       {
         //Assigns values from the file
         GPU_speed = inputFile.nextDouble();
         CPU_speed = inputFile.nextDouble();
         ProcessorCores = inputFile.nextInt();
         resolutionChoice = inputFile.nextInt();
         
         //Peforms a certain set of actions depending on the user's resolution selection.
         switch (resolutionChoice)             
         {
            case 1:
            {
               resolution = "1280 x 720";      //Assigns a new string to the "resolution" variable depending on and reflecting user resolution choice.
               multiplier = 1;                 //Assigns a new value to "multiplier" variable based on the resolution choice
            break;
            }
            
            case 2:
            {
               resolution = "1920 x 1080";    
               multiplier = 0.75;            
            break;
            }   
            
            case 3:
            {
               resolution = "2560 x 1440";
               multiplier = 0.55;         
            break;
            }
            
            case 4:
            {
               resolution = "3840 x 2160";
               multiplier = 0.35;         
            break;
            }
         }
         
         //Calculates and assigns a value to the performance score using values previously given by the file.
         performanceScore = (double)((5 * GPU_speed) + (ProcessorCores * CPU_speed)) * multiplier;
               
               /*Checks if the first record in the file is being used & sets 
               both the highest and lowest scores to the first record*/
               if (firstFile == true)
               {
                  highestScore = performanceScore;
                  lowestScore = performanceScore;
                  firstFile = false;         //Insures that the block is only used with the first record.
               }
               
               /*Reads every record to see if the performanceScore found 
               that calculated score is the highest or lowest score.*/ 
               else 
               {
                  if (performanceScore > highestScore)
                     highestScore = performanceScore;
                     
                  else if (performanceScore < lowestScore)
                     lowestScore = performanceScore;
               }
               
                  
             /* Assigns "Ultra", "High", "Medium", "Low", or "Unable to Play" string values to the 
             "Recommended_Graphics_Quality" depending on the value stored in the "performanceScore" variable */
               if (performanceScore > 17000)
               {
                  Recommended_Graphics_Quality = "Ultra";
               }
               
               else if (performanceScore > 15000 && performanceScore <= 17000)
               {
                  Recommended_Graphics_Quality = "High";
               }
               
               else if (performanceScore > 13000 && performanceScore <= 15000)
               {
                  Recommended_Graphics_Quality = "Medium";
               }
               
               else if (performanceScore > 11000 && performanceScore <= 13000)
               {
                  Recommended_Graphics_Quality = "Low";
               }
               
               else if (performanceScore <= 11000)
               {
                  Recommended_Graphics_Quality = "Unable to Play";
               }
               
          /*Displays the user's for GPU and CPU clock speeds, number of cores, selected monitor resolution,
          calculated performance score, and Recommended Graphics Quality*/
               System.out.printf("\n" +
                      "GPU Clock Speed: %.1f MHz\n" +
                      "CPU Clock Speed: %.1f MHz\n" +
                      "Number of cores: %d\n" +
                      "Monitor Resolution: %s\n" +
                      "Performance Score: %.3f\n" +
                      "Recommended Graphics Quality: %s\n", GPU_speed, CPU_speed, ProcessorCores, resolution, performanceScore, Recommended_Graphics_Quality);
       }
               inputFile.close(); //Closes the file.
               
               //Displays the highest and lowest score after the loop concludes
               System.out.printf("\nThe highest performance score was: %.3f", highestScore);
               System.out.printf("\nThe lowest performance score was: %.3f", lowestScore);
               System.exit(0);
   }

}