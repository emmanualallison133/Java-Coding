/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dateproject;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author lcao2
 */
public class DateProject {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args){
        
        Scanner scanner = new Scanner(System.in);
        int month, day, year;
        
        while(true){
            try{
                    System.out.print("Enter an integer value for month: ");
                    month = scanner.nextInt();
                    break;
                }
            catch(InputMismatchException e){
                    System.out.println("Invalid input. You must enter an integer.");
                    scanner.nextLine();
            }
        }
        
        while(true){
            try{
                    System.out.print("Enter an integer value for day: ");
                    day = scanner.nextInt();
                    break;
            }catch(InputMismatchException e){
                    System.out.println("Invaild input. You must enter an integer.");
                    scanner.nextLine();
            }
        }
        
        while(true){
            try{
                System.out.print("Enter an integer value for year: ");
                year = scanner.nextInt();
                break;
            }catch(InputMismatchException e){
                System.out.println("Invalid input. You must enter an integer.");
                scanner.nextLine();
            }
        }
        
        try{
            Date date = new Date(month, day, year);
            System.out.println(date);
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
        
    }
}
