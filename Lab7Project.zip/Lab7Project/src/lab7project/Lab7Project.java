/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7project;

import java.util.ArrayList;

/**
 *
 * @author lcao2
 */
public class Lab7Project {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<Person> list = new ArrayList<Person>();
        
        Person alice = new Person("Alice", 1000);
        Student keisha = new Student("Keisha", 900, "CS", 3.5);
        Student felipe = new Student("Felipe", 901, "English", 3.2);
        Professor jamika = new Professor("Jamika", 300, "CS", 101000);
        Person tala = new Person("Tala", 1001);
        Professor julio = new Professor("Julio", 400, "Math", 85000);
        Student huan = new Student("Huan", 902, "CS", 3.6);
        Student hank = new Student("Hank", 903, "Engineering", 3.9);
        Student mike = new Student("Mike", 904, "Math", 2.8);
        Professor azzari = new Professor("Azzari", 500, "CS", 100000);
        Professor juan = new Professor("Juan", 600, "CS", 980000);
        
        list.add(alice);
        list.add(keisha);
        list.add(felipe);
        list.add(jamika);
        list.add(tala);
        list.add(julio);
        list.add(huan);
        list.add(hank);
        list.add(mike);
        list.add(azzari);
        list.add(juan);
        
        for(Person p: list){
            System.out.println(p);
        } 
        
        System.out.println("");
        
        for(Person s: list){
            if(matchId(s, 903)== true)
                System.out.println(s);
        }
        
        System.out.println("");
        
        System.out.println("The following students are eligible for the scholarship:");
        for(Person p : list){
            if(p instanceof Student){
                if(((Student) p).getGpa() > 3.5) 
                    System.out.println(p.getName());
                
            } 
        }
        
        System.out.println("");
        
        System.out.println("The following professors are in the CS department:");
        for(Person p : list){
            if(p instanceof Professor){
                if(((Professor) p).getDepartment() == "CS")
                    System.out.println(p.getName());
            }
        }
    }
    public static boolean matchId(Person p, int id){
        if(p.getId() == id)
            return true;
        else
            return false;
    }    
}
