/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab1rectangle;

import java.awt.Rectangle;

/**
 *
 * @author Emmanual Allison
 */
public class Lab1Rectangle {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Rectangle box1 = new Rectangle(10, 10, 40, 30);
        System.out.println("box1: " + box1);
        
        Rectangle box2 = new Rectangle(100, 50);
        System.out.println("box2: " + box2);
        
        box1.setLocation(20, 20);
        box2.setSize(50, 30);
        
        System.out.println("box1: " + box1);
        System.out.println("box2: " + box2);
        
        Rectangle box3 = new Rectangle();
        
        box3 = box1.intersection(box2);
        
        double box3_Width = box3.getWidth();
        double box3_Height = box3.getHeight();
        
        System.out.println("Intersecting area is " + (box3_Width * box3_Height));
        
        System.out.println("box3:" + box3);
    }
    
}
