package Lab4Project;

import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Emmanual Allison
 */
public class BurgerOrder {
    
    private int numHamburgers = 0;
    private int numCheeseburgers = 0;
    private int numVeggieburgers = 0;
    private int numSodas = 0;
    private boolean orderTogo = false;
    private int orderNum = 36;
    
    final private double hamburgerCost = 4.49;
    final private double cheeseburgerCost = 5.00;
    final private double veggieburgerCost = 6.49;
    private final double sodaCost = 2.99;
    private double totalCost = 0.00;

    Scanner scnr = new Scanner(System.in);
    /**
     *
     * @param numHamburgers
     * @param numCheeseburgers
     * @param numVeggieburgers
     * @param numSodas
     * @param orderTogo
     * @param orderNum
     */
    public BurgerOrder(int Hamburgers, int Cheeseburgers, int Veggieburgers, int Sodas, boolean Togo, int Num) {
        numHamburgers = Hamburgers;
        numCheeseburgers = Cheeseburgers;
        numVeggieburgers = Veggieburgers;
        numSodas = Sodas;
        orderTogo = Togo;
        orderNum = Num;
    }

    public double getTotalCost() {
        return totalCost;
    }

    public void calculateTotalCost(int numHamburgers, int numCheeseburgers, int numVeggieburgers, int numSodas){
       totalCost = (numHamburgers * hamburgerCost) + (numCheeseburgers * cheeseburgerCost) + 
               (numVeggieburgers * veggieburgerCost)+(numSodas * sodaCost);
    }
    /** 
     * Get the value of orderNum
     *
     * @return the value of orderNum
     */
    public int getOrderNum() {
        return orderNum;
    }

    /**
     * Set the value of orderNum
     *
     * @param orderNum new value of orderNum
     */
    public void setOrderNum(int orderNum) {
        this.orderNum = orderNum;
    }


    /**
     * Get the value of orderTogo
     *
     * @return the value of orderTogo
     */
    public boolean isOrderTogo() {
        return orderTogo;
    }

    /**
     * Set the value of orderTogo
     *
     * @param orderTogo new value of orderTogo
     */
    public void setOrderTogo(boolean orderTogo) {
        this.orderTogo = orderTogo;
    }

    /**
     * Get the value of numSodas
     *
     * @return the value of numSodas
     */
    public int getNumSodas() {
        return numSodas;
    }

    /**
     * Set the value of numSodas
     *
     * @param numSodas new value of numSodas
     */
    public void setNumSodas(int numSodas) {
        
        while (numSodas < 0){
            System.out.println("ERROR!: The number of sodas cannot be negative");
            System.out.println("Please try again: ");
            numSodas = scnr.nextInt();
        }
        this.numSodas = numSodas;
    }


    /**
     * Get the value of numVeggieburgers
     *
     * @return the value of numVeggieburgers
     */
    public int getNumVeggieburgers() {
        return numVeggieburgers;
    }

    /**
     * Set the value of numVeggieburgers
     *
     * @param numVeggieburgers new value of numVeggieburgers
     */
    public void setNumVeggieburgers(int numVeggieburgers) {
        while (numVeggieburgers < 0){
            System.out.println("ERROR!: The number of veggieburgers cannot be negative");
            System.out.println("Please try again: ");
            numVeggieburgers = scnr.nextInt();
        }
        this.numVeggieburgers = numVeggieburgers;
    }


    /**
     * Get the value of numCheeseburgers
     *
     * @return the value of numCheeseburgers
     */
    public int getNumCheeseburgers() {
        return numCheeseburgers;
    }

    /**
     * Set the value of numCheeseburgers
     *
     * @param numCheeseburgers new value of numCheeseburgers
     */
    public void setNumCheeseburgers(int numCheeseburgers) {
        while (numCheeseburgers < 0){
            System.out.println("ERROR!: The number of cheeseburgers cannot be negative");
            System.out.println("Please try again: ");
            numCheeseburgers = scnr.nextInt();
        }
        this.numCheeseburgers = numCheeseburgers;
    }


    /**
     * Get the value of numHamburgers
     *
     * @return the value of numHamburgers
     */
    public int getNumHamburgers() {
        return numHamburgers;
    }

    /**
     * Set the value of numHamburgers
     *
     * @param numHamburgers new value of numHamburgers
     */
    public void setNumHamburgers(int numHamburgers) {
        while (numHamburgers < 0){
            System.out.println("ERROR!: The number of hamburgers cannot be negative");
            System.out.println("Please try again: ");
            numHamburgers = scnr.nextInt();
        }
        this.numHamburgers = numHamburgers;
    }

    @Override
    public String toString() {
        return "BurgerOrder{" + "numCheeseburgers=" + numCheeseburgers + ", numHamburgers=" + numHamburgers + ", numVeggieburgers=" + numVeggieburgers + ", numSodas=" + numSodas + ", orderTogo=" + orderTogo + ", orderNum=" + orderNum + '}';
    }
    
    

}
