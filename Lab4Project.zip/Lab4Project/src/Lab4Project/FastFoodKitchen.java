/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lab4Project;

import java.util.ArrayList;

/**
 *
 * @author Emmanual Allison
 */
public class FastFoodKitchen {
    private ArrayList <BurgerOrder> orderList = new ArrayList <BurgerOrder>();
    private static int nextOrderNum;

    public FastFoodKitchen() {
        orderList.add(new BurgerOrder(3, 5, 4, 10, false, 
        getNextOrderNum()));
        incrementNextOrderNum();
        
        orderList.add(new BurgerOrder(0, 0, 3, 3, true, 
        getNextOrderNum()));
        incrementNextOrderNum();
        
        orderList.add(new BurgerOrder(1, 1, 0, 2, false, 
        getNextOrderNum()));
        incrementNextOrderNum();
    }
    
    
    /**
     * Get the value of nextOrderNum
     *
     * @return the value of nextOrderNum
     */
    public static int getNextOrderNum() {
        return nextOrderNum;
    }
    
    private static void incrementNextOrderNum(){
        nextOrderNum += 1;
    }
    /**
     * Creates a new BurgerOrder class and adds 
     * the burger order to the order list.
     * 
     * @param ham The number of hamburgers in the new order
     * @param cheese The number of cheeseburgers in the new order
     * @param veggie The number of veggie burgers in the new order
     * @param soda The number of sodas in the new order
     * @param TOGO Determines if this is a to-go order. Is assigned "true" if this is a take out order.
     * @return nextOrderNum Returns the next order's number.
     */
    public int addOrder(int ham, int cheese, int veggie, int soda, boolean TOGO){
        BurgerOrder newOrder = new BurgerOrder(ham, cheese, veggie, soda, TOGO, getNextOrderNum());
        orderList.add(newOrder);
        incrementNextOrderNum();
        
        return (newOrder.getOrderNum());
    }

    /**
     * Checks through every order in the order list and
     * compares it to the order ID see if
     * an order is still in progress.
     * 
     * @param orderID The current order's ID number.
     * @return Returns "true" if an order number in the order list
     * does not match the order's ID. 
     * Returns "false" if an order number in the order list matches
     * the order's ID, indicating that the order is still in progress.
     */
    public boolean isOrderDone(int orderID){
        
        boolean orderDone = false;
        
        for(int i = 0; i < orderList.size(); i++){
            if (orderList.get(i).getOrderNum() == orderID)
                orderDone = false;
            else if (orderList.get(i).getOrderNum() != orderID)
                orderDone = true;
        }
        
        return orderDone;
    }
    
    /**
     * Prints the number of each food item in an order if there is 
     * at least of the item in the order.
     * 
     * @param order The BurgerOrder class that contains the number of
     * each food item
     */
    private void orderCallOut(BurgerOrder order){
        System.out.println("There are: ");
        
        if (order.getNumHamburgers()> 0)
            System.out.println(order.getNumHamburgers() + " Hamburger(s)");
        
        if (order.getNumCheeseburgers()> 0)
            System.out.println(order.getNumCheeseburgers() + " Cheeseburger(s)");
        
        if (order.getNumVeggieburgers()> 0)
            System.out.println(order.getNumVeggieburgers()+ " Veggieburger(s)");
        
        if (order.getNumSodas() > 0)
            System.out.println(order.getNumSodas() + " Soda(s)");
            
        System.out.println("in this order.");
        System.out.println("");
    }
    /**
     * Finds the order in the order list that has the matching
     * order number, calls out that the order is done, announces
     * the details of the order if the order is to go, and removes the
     * order from the order list.
     * 
     * @param orderID The current order's ID number.
     */
    private void completeSpecificOrder (int orderID){
       
        for (BurgerOrder object : orderList){
            if(object.getOrderNum() == orderID)
            System.out.println("Order Number " + orderID + " is done!");
        }

        if(orderList.get(orderID).isOrderTogo())
            orderCallOut(orderList.get(orderID));
        
        orderList.remove(orderID);
    }
    /**
     * Finds the first order in the list, calls out that the
     * order is done, announces the details of the 
     * order if the order is to go, and removes the 
     * order from the order list.
     */
    private void completeNextOrder(){
        
        orderList.get(0);
        System.out.println("");
        System.out.println("Order Number " + orderList.get(0).getOrderNum() + " is done!");
        System.out.println("");

        
        if (orderList.get(0).isOrderTogo())
            orderCallOut(orderList.get(0));
        
        orderList.remove(0);
    }
    
    /**
     * @return Returns the number of orders currently
     * in the order list.
     */
    public int getNumOrdersPending(){
        return orderList.size();
    }
    
    /**
     * Looks at the order list to see if there are any 
     * orders left to do. Simulates activity in the kitchen
     * where most orders are completed on a first come, 
     * first served basis. 
     */
    public void simulateKitchenActivity(){
        // see if there is anything to do
        if (orderList.size() == 0) 
            return;
        // simulate how orders are completed, usually
        // first-in, first-out, but not always
        int num = (int)(Math.random()*100);
        if (num < 90) {
        // 90% chance the kitchen completes the order that is at
        // the front of the queue
        completeNextOrder();
        } else {
        // complete some random order
        int size = orderList.size();
        int id = (int)(Math.random()*size);
        completeSpecificOrder(id);
        }
    }

    @Override
    public String toString() {
        return "FastFoodKitchen{" + "orderList=" + orderList + '}';
    }
    
    public boolean cancelOrder(int orderID){
        for(int i = 0; i < orderList.size(); i++){
            if (orderList.get(i).getOrderNum() == orderID){
                orderList.remove(i);
                return true;
            }
        }
        
        return false;
    }
}

           