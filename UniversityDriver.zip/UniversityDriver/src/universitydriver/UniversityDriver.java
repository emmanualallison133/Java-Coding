/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package universitydriver;

/**
 *
 * @author Emmanual Allison
 */
public class UniversityDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*Student hakim = new Student();
        Student maria =  new Student("Maria", 'L', "Garces", "800555555", 19,
        true);
        
        System.out.println(hakim.getFirstName());
        System.out.println(hakim.getMiddleInitial());
        System.out.println(hakim.getLastName());
        System.out.println(hakim.getStudentId());
        System.out.println(hakim.getAge());
        System.out.println(hakim.isLiveOnCampus());
        System.out.println("");
        
        System.out.println(maria.getFirstName());
        System.out.println(maria.getMiddleInitial());
        System.out.println(maria.getLastName());
        System.out.println(maria.getStudentId());
        System.out.println(maria.getAge());
        System.out.println(maria.isLiveOnCampus());
        */
        
        Student torrance = new Student("Luis", 'J', "DeLeon", "800234567",
        19, false);
        
        System.out.println("Object torrance first name is " +
        torrance.getFirstName());
        torrance.setFirstName("Michel");
        System.out.println("Object torrance first name is " +
        torrance.getFirstName());
        
        torrance.setLastName("Williams");
        System.out.println("Object torrance last name is " + torrance.getLastName());
        
        torrance.setMiddleInitial('G');
        System.out.println("Object torrance middle initial is " + torrance.getMiddleInitial());
        
        torrance.setStudentId("9999999");
        System.out.println("Object torrance student ID is " + torrance.getStudentId());

        torrance.setAge(89);
        System.out.println("Object torrance age is " + torrance.getAge());
        
        torrance.setLiveOnCampus(true);
        System.out.println("Object torrance lives on campus is " + torrance.isLiveOnCampus());
        
        System.out.println("");
        
        torrance.payFromCard(9);
        torrance.transferToCard(89);
        torrance.transferToCard(69);
        torrance.transferToCard(-9);
        torrance.payFromCard(15);
        torrance.payFromCard(8);
        
    }
    
}
