/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package universitydriver;

/**
 * The student class completes operations with a student's personal info and card balance.
 * @author Emmanual Allison
 * @version 1.00
 */
public class Student {
    private String firstName;
    private char middleInitial;
    private String lastName;
    private String studentId;
    private int age;
    private boolean liveOnCampus;
    private double cardBalance;

    /**
     * 1st Constructor to initialize the instance variables
     */
    Student() {
        this.firstName = firstName;
        this.middleInitial = middleInitial;
        this.lastName = lastName;
        this.studentId = studentId;
        this.age = age;
        this.liveOnCampus = liveOnCampus;
        cardBalance = 0.00;
        
     
    }
    
    /**
     * Gets the student's current card balance
     * @return cardBalance, a double variable
     */
    public double getCardBalance() {
        return cardBalance;
    }
    
    /**
     * Adds a dollar amount to the student's card balance
     * @param amount a double variable, the money to be added to the current card balance.
     */
    public void transferToCard(double amount){
        if(amount > 0){
            cardBalance += amount;
            System.out.println("Your new balance is $" + cardBalance);
        }
        
        else
            System.out.println("The transfer amount must be greater than 0");
    }
    
    /**
     * Removes an amount from the card balance if there are sufficent funds. Prints an error message otherwise
     * @param amount a double variable, the money to be paid by the current card balance.
     */
    public void payFromCard (double amount){
        if(amount <= cardBalance){
            cardBalance -= amount;
            System.out.println("Your new balance is $" + cardBalance);
        }
        
        else
            System.out.println("Sorry, your balance is too low!");
    }
    
    /**
     * 2nd Constructor that initializes the instance variables by accepting parameters
     * @param firstName A String variable that holds the student's first name.
     * @param middleInitial A char variable that holds the student's middle initial.
     * @param lastName A String variable holds that the student's last name.
     * @param studentId A String variable that holds the student's ID number
     * @param age An int variable that holds the student's age number
     * @param liveOnCampus A boolean variable that determines if the student lives on campus
     */
    public Student(String firstName, char middleInitial, String lastName, String studentId, int age, boolean liveOnCampus) {
        this.firstName = firstName;
        this.middleInitial = middleInitial;
        this.lastName = lastName;
        this.studentId = studentId;
        this.age = age;
        this.liveOnCampus = liveOnCampus;
        cardBalance = 0.00;
    }
    
    /**
     * Gets the student's first name
     * @return firstName, A String variable
     */
    public String getFirstName() {
        return firstName;
    }
    
    /**
     * Gets the student's middle initial
     * @return middleInitial, a char variable
     */
    public char getMiddleInitial() {
        return middleInitial;
    }

    /**
     * Gets the student's last name
     * @return lastName, a String variable
     */
    public String getLastName() {
        return lastName;
    }
    
    /**
     * Gets the student's ID 
     * @return studentId, a String variable
     */
    public String getStudentId() {
        return studentId;
    }

    /**
     * Gets the student's age number
     * @return age, an int variable
     */
    public int getAge() {
        return age;
    }
    
    /**
     * Gets whether or not the student lives on campus
     * @return liveOnCampus, a boolean variable
     */
    public boolean isLiveOnCampus() {
        return liveOnCampus;
    }
    
    /**
     * Sets the first name of the Student 
     * @param fName, a String variable
     */
    public void setFirstName(String fName) {
        firstName = fName;
 }

    /**
     * Sets the middle initial of the student
     * @param midInitial, a char variable
     */
    public void setMiddleInitial(char midInitial) {
        middleInitial = midInitial;
    }

    /**
     * Sets the last name of the student 
     * @param lName, a String variable
     */
    public void setLastName(String lName) {
        lastName = lName;
    }

    /**
     * Sets the student's ID number
     * @param studId, a String variable
     */
    public void setStudentId(String studId) {
        studentId = studId;
    }

    /**
     * Sets the age of the student
     * @param ageNum, an int variable
     */
    public void setAge(int ageNum) {
        age = ageNum;
    }
    
    /**
     * Sets whether or not the student lives on campus
     * @param onCampus, a boolean variable
     */
    public void setLiveOnCampus(boolean onCampus) {
        liveOnCampus = onCampus;
    }
    
}
