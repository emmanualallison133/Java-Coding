import java.util.Scanner;  //For the Scanner class
import java.io.*;          //For file I/O classes

/*
   This program opens the Computer.txt file representing several client's 
   computer setups and utilizes several different methods to 
   display the recommended graphics each client they should play a game at.
*/

public class Project3_emmanuel_allison
{
   public static void main(String[] args) throws IOException 
   {
      //Holds the program's title
      final String programTitle = "Computer Hardware Graphics Quality Recommendation Tool"; 
      
      int resolutionChoice = 0; //Holds the user's choice of resolution
      int ProcessorCores = 0; //Hold the number of processor cores 
      
      //Holds the strings represents the user's Monitor Resolution and their Recommended Quality respectively
      String Monitor_Resolution = null, Recommended_Quality = null; 
      
      //Holds the computer setup values to be used in the program
      double GPU_Clock_Speed = 0.00, CPU_Clock_Speed = 0.00, multiplier = 0.00;
      double performanceScore = 0.00, Highest_Score = 0.00, Lowest_Score = 0.00;
      
      //Set to true if it is the first file in the .txt document 
      boolean First_file = true;
      
      //Sends the programTitle string as an argument to the "displayTitle" method
      displayTitle(programTitle);
      
      //Opens the file
      File file = new File("Computers.txt");
      Scanner inputFile = new Scanner(file);
      
      //A loop that ensures that each file in the .txt document is used.
      while (inputFile.hasNext())
      {
         GPU_Clock_Speed = inputFile.nextDouble(); //Collects the GPU Clock Speed from the file 
         CPU_Clock_Speed = inputFile.nextDouble(); //Collects the CPU Clock Speed from the file
         ProcessorCores = inputFile.nextInt();     //Collects the number of processor cores from the file
         resolutionChoice = inputFile.nextInt();   //Collects the choice of resolution from the file
         
         
         //Sends the resolution choice as a argument and recieves the returned 
         //string for the monitor resolution.
         Monitor_Resolution = getResolutionString(resolutionChoice);
         
         //Sends the resolution choice as a argument and stores the
         //returned �multiplier� value.
         multiplier = getMultiplierValue(resolutionChoice);
         
         //Sends the GPU clock speed, CPU clock speed, the number of cores, 
         //and the multiplier value, and stores the returned performance score. 
         performanceScore = calculatePerformanceScore(GPU_Clock_Speed, CPU_Clock_Speed, ProcessorCores, multiplier);
         
         //Checks if the first file is being checked and the score the value in the 
         //first performance score the highest and lowest performance score
         if(First_file == true)
         {
            Highest_Score = performanceScore;
            Lowest_Score = performanceScore;
            
            //Makes sure that this block is not used for subsequent files after the first
            First_file = false;  
         }
         
         //Stores the highest score if the current loop's score is 
         //higher than the highest score stored.
         if (performanceScore > Highest_Score)
            Highest_Score = performanceScore;
            
         //Stores the lowest score if the current loop's score is 
         //lower than the lowest score stored.   
         if (performanceScore < Lowest_Score)
            Lowest_Score = performanceScore; 
         
         //Sends the peformance score as arguments and recieves the recommended 
         //graphics quality string
         Recommended_Quality = getRecommendedQuality(performanceScore);
         
         //Prints out the information for a single computer.
         displayInformation(GPU_Clock_Speed, CPU_Clock_Speed, ProcessorCores, Monitor_Resolution, performanceScore, Recommended_Quality);
      }
      
      //Closes the file once there are no more lines to read & the loop finishes
      inputFile.close();
      
      //Displays the highest and lowest values.
      System.out.printf("The highest performance score was: %.3f\n", Highest_Score);
      System.out.printf("The lowest performance score was: %.3f", Lowest_Score);
      
      //Ends the program
      System.exit(0);
   }
   
   /**
      The displayTitle method recieves the progam title 
      string as a parameter and displays it.
   */
   
   public static void displayTitle(String title)
   {
      System.out.println(title + "\n"); 
   }
   
   /**
      The getResolutionString method accept an integer value 
      (1, 2, 3, or 4) that denotes the monitor resolution and returns
      the string representation of the monitor resolution.
   */
   
   public static String getResolutionString(int choice)
   {
      String resolution = null;
      
      switch (choice)
      {
         case 1:
         {
            resolution = "1280 x 720";
            break;
         }
         
         case 2:
         {
            resolution = "1920 x 1080"; 
            break;
         }
         
         case 3:
         {
            resolution = "2560 x 1440";
            break;
         }
         
         case 4:
         {
            resolution = "3840 x 2160";
            break;
         }
      }
      
      return resolution;
   }
   
   /**
      The getMultiplierValue method accepts an integer value 
      (1, 2, 3, or 4) that denotes the monitor resolution and 
      returns the appropriate �multiplier� value.
   */
   
   public static double getMultiplierValue(int resolutionChoice)
   {
      double multiplier = 0.00;
      
      switch (resolutionChoice)
      {
         case 1:
         {
            multiplier = 1;
            break;
         }
         
         case 2:
         {
            multiplier = 0.75;
            break;
         }
         
         case 3:
         {
            multiplier = 0.55;
            break;
         }
         
         case 4:
         {
            multiplier = 0.35;
            break;
         }
      }
      
      return multiplier;
   }
   
   /**
      The calculatePerformanceScore method the GPU clock speed, CPU clock speed, 
      the number of cores, and the multiplier value, and calculates and
      returns the performance score. 
   */
   
   public static double calculatePerformanceScore(double GPU, double CPU, int cores, double multiplier)
   {
      double score = 0.00;
      score = (double)((5 * GPU) + (cores * CPU)) * multiplier;
      
      return score;
   }
   
   /**
      The getRecommendedQuality method accepts a performance score 
      as an argument and returns the recommended graphics quality based
      on the performance score.
   */
   
   public static String getRecommendedQuality(double score)
   {
      String quality = null;
      
         if (score > 17000)
         {
            quality = "Ultra";
         }
         
         else if (score > 15000 && score <= 17000)
         {
            quality = "High";
         }
         
         else if (score > 13000 && score <= 15000)
         {
            quality = "Medium";
         }
         
         else if (score > 11000 && score <= 13000)
         {
            quality = "Low";
         }
         
         else if (score < 11000)
         {
            quality = "Unable to Play";
         }
         
      return quality;
   }
   
   /**
      The displayInformation method recieves and displays the 
      information for a single computer.
   */
   
   public static void displayInformation(double GPU, double CPU, int cores, String Monitor_Resolution, double score, String quality)
   {
      System.out.printf("GPU Clock Speed: %.1f MHz\n", GPU);
      System.out.printf("CPU Clock Speed: %.1f MHz\n", CPU);
      System.out.printf("Number of cores: %d \n", cores);
      System.out.printf("Monitor Resolution: %s \n", Monitor_Resolution);
      System.out.printf("Performance Score: %.3f \n", score);
      System.out.printf("Recommended Graphics Quality: %s \n\n", quality);
   }
}