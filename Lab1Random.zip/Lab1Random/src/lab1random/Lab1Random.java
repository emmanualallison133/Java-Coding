/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab1random;

import java.util.Random;

/**
 *
 * @author Emmanual Allison
 */
public class Lab1Random {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Random rndm = new Random(100);
        double rndmVal;
        final double minRange = 0.0, maxRange = 100.0;
        
        for(int i = 0; i < 10; i++){
        System.out.print(rndm.nextInt(100) + " ");
        }
        
        System.out.println();
      
        System.out.println((rndm.nextInt(100) - 50));
        
        System.out.println(rndm.nextDouble());
        
        rndmVal = minRange + (maxRange - minRange) * rndm.nextDouble();
        
        System.out.println(rndmVal);
    }
}
