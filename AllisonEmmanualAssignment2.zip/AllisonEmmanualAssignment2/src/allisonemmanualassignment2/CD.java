/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package allisonemmanualassignment2;

/**
 *
 * @author Emmanual Allison
 */
public class CD extends Account{
    private int yearOfAccountCreation;  //Holds what year the account was created
    private int currentYear;            //Holds what year it is currently
    private double intitalBalance;      //Holds the initalBalance
    
    /**
     * Constructor
     * @param nameOfAccount
     * @param PIN
     * @param initialBalance
     * @param yearOfAccountCreation 
     */
    public CD(String nameOfAccount, int PIN, double initialBalance, int yearOfAccountCreation) {
        super(nameOfAccount, PIN, initialBalance);
        this.intitalBalance = initialBalance;   //Holds the amount that was orginally placed into the CD account
        this.yearOfAccountCreation = yearOfAccountCreation;
    }
    
    /**
     * Prints an error message as CD accounts cannot be withdrawn from as they are maturing
     * @param amount 
     */
    @Override
    public void withdrawal(double amount){
        System.out.println("You are unable to withdrawal from a CD account while it is maturing");
        System.out.println("Exiting withdrawal option...");
    }
    
    /**
     * Sets the current year
     * @param currentYear 
     */
    public void setCurrentYear(int currentYear) {
        this.currentYear = currentYear;
    }
    
    /**
     * Gets the current year
     * @return The current year
     */
    public int getCurrentYear() {
        return currentYear;
    }

    /**
     * Sets the balance of how much is currently in the maturing CD account in the current year.
     */
    public void setCurrentBalance(){
        super.setBalance(this.intitalBalance*(Math.pow(1 + .0003/12, 12 * (currentYear - yearOfAccountCreation))));
    }
    
    /**
     * Gets the year the account will be fully matured, which is three
     * years after the account was created
     * @return The year the account will have matured
     */
    public int getMaturityYear(){
        return yearOfAccountCreation + 3;
    }
    
    @Override
    /**
     * Prints an error message as CD accounts cannot be deposited into while they are maturing.
     * Overrides the deposit method in the Account superclass
     */
    public void deposit(double amount) {
        System.out.println("You are unable to deposit money into CD while it is maturing");
        System.out.println("Exiting deposit option...");
    }
    
    @Override
    /**
     * Prints the information of the CD class
     * Overrides the printInfo method in the Account superclass
     */
    public void printInfo(){
        System.out.println("Account Type: CD");
        super.printInfo();
        System.out.println("Year of Account Creation: " + yearOfAccountCreation);
        System.out.println("Year to be matured and withdrawn from: " + getMaturityYear());
        System.out.println("Years until maturity: " + (getMaturityYear() - currentYear));
        System.out.println("********************************************");
    }

    

    
}
