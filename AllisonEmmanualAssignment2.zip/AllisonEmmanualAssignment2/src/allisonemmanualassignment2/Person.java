/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package allisonemmanualassignment2;

/**
 *
 * @author Emmanual Allison
 */
public abstract class Person {
    private String name;
    private String address;
    private String email;

    /**
     * Constructor for the person abstract class
     * @param name Holds the person's name
     * @param address Holds the person's address
     * @param email Holds the person's  email
     */
    public Person(String name, String address, String email) {
        this.name = name; //Assigns the name parameter as the current class' name field
        this.address = address; //Assigns the address parameter as the current class' address field
        this.email = email; //Assigns the email parameter as the current class' email field
    }

    /**
     * Getter for the person's name
     * @return The person's name
     */
    public String getName() {
        return name;
    }

    /**
     * Setter for the person's name
     * @param name The name to be set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Getter for the person's address
     * @return The person's address
     */
    public String getAddress() {
        return address;
    }

    /**
     * Setter for the person's address
     * @param address The address to be set
     */
    public void setAddress(String address) {
        this.address = address;
    }


    /**
     * Getter for the person's email
     * @return The person's email
     */
    public String getEmail() {
        return email;
    }

    /**
     * Setter for the person's email
     * @param email The email to be set
     */
    public void setEmail(String email) {
        this.email = email;
    }
    
    /**
     * Shows the name, address, and email address of the person
     */
    public void printInfo(){
        System.out.println("Name: " + name);
        System.out.println("Address: " + address);
        System.out.println("Email Address: " + email);
    }
}
