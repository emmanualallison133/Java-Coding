/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package allisonemmanualassignment2;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *  
 * @author Emmanual Allison
 */
public class Start {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        /*
            The five major functions of the program are to create multiple 
            checking, savings, and CD accounts, withdrawal and deposit from those accounts.
        */
        
        
        ArrayList<Account> accounts = new ArrayList<Account>();     //An ArrayList for all the Checking, Savings, and CD account objects
        ArrayList<Person> people = new ArrayList<Person>();     //An ArrayList for all the Employee and Customer profile objects
        
        Scanner scnr = new Scanner(System.in);      //Allows input to be read from the user
        int yearNum = 2000;     //Stores the current year. Used for CD accounts
        String choice;      //Stores the choice the user makes in the menu
        
        //Displays the program's header.
        System.out.println("******************************************************************");
        System.out.println("*   Welcome to the Fifth Third Bank of Wells-Fargos in America!  *");
        System.out.println("******************************************************************");
        System.out.println("\t\t     It is currently the year " + yearNum);
        displayMenu();      //Calls the displayMenu() method to show the menu options
        
        choice = scnr.nextLine();       //Stores the user's choice of operation
        
        //Allows the user to continue selecting menu options until they select 0 at the menu screen
        while(choice != "0"){
            switch(choice){
                
                //Creates a new Checking account
                case "1":
                    //Calls the createCheckingAccount method by sending the accounts ArrayList as an argurment
                    //and adding the returned Account class into the accounts ArrayList
                    accounts.add(createCheckingAccount(accounts)); 
                    System.out.println("\nAccount created and added to the system!");
                    System.out.println("\nHere are the accounts that are currently in the system");
                    
                    //Goes through all of the Account classes in the accounts ArrayList
                    for(Account e : accounts){
                        if(e instanceof CD){
                            ((CD) e).setCurrentYear(yearNum); //Updates the year of all CD accounts
                            ((CD) e).setCurrentBalance();   //Updates the current accumulated balance of the CD account
                        }
                        System.out.println("");
                        e.printInfo();      //Print the information of all accounts in the accounts ArrayList
                    }
                    
                    //Adds one year to the year number
                    yearNum++;      
                    
                    System.out.println("\nOne year has passed and it is now the year " + yearNum);
                    
                    //Loops through every person in the people ArrayList
                    for(Person p : people){
                        if(p instanceof Customer)
                            //Adds one year all the customers' ages because a year has passed 
                            ((Customer) p).setAge(((Customer) p).getAge() + 1);
                    }
                    
                    //Calls the checkCDAccountMaturity method to check if any CD accounts have fully matured
                    accounts = checkCDAccountMaturity(accounts, yearNum);
                    
                    
                    displayMenu();  //Displays the menu
                    choice = scnr.nextLine(); //Stores the user's menu choice
                    break;
                
                //Creates a new Savings account
                case "2":
                    
                    //Calls the createSavingsAccount method by sending the accounts ArrayList as an argurment
                    //and adding the returned Account class into the accounts ArrayList
                    accounts.add(createSavingsAccount(accounts));
                    
                    System.out.println("\nAccount created and added to the system!");
                    System.out.println("\nHere are the accounts that are currently in the system");
                    
                    //Goes through all of the Account classes in the accounts ArrayList
                    for(Account e : accounts){
                        if(e instanceof CD){
                            ((CD) e).setCurrentYear(yearNum); //Updates the year of all CD accounts
                            ((CD) e).setCurrentBalance();   //Updates the current accumulated balance of the CD account
                        }
                        System.out.println("");
                        e.printInfo();      //Print the information of all accounts in the accounts ArrayList
                    }
                    
                    //Adds one year to the year number
                    yearNum++;      
                    
                    System.out.println("\nOne year has passed and it is now the year " + yearNum);
                    
                    //Loops through every person in the people ArrayList
                    for(Person p : people){
                        if(p instanceof Customer)
                            //Adds one year all the customers' ages because a year has passed 
                            ((Customer) p).setAge(((Customer) p).getAge() + 1);
                    }
                    
                    //Calls the checkCDAccountMaturity method to check if any CD accounts have fully matured
                    accounts = checkCDAccountMaturity(accounts, yearNum);
                    
                    
                    displayMenu();      //Displays the menu
                    choice = scnr.nextLine(); //Stores the user's menu choice
                    break;
                    
                case "3":
                    //Calls the createCDAccount method and adds the returned CD account object into the accounts ArrayList
                    accounts.add(createCDAccount(accounts, yearNum));
                    System.out.println("\nAccount created and added to the system!");
                    System.out.println("\nHere are the accounts that are currently in the system");
                    
                    //Goes through all of the Account classes in the accounts ArrayList
                    for(Account e : accounts){
                        if(e instanceof CD){
                            ((CD) e).setCurrentYear(yearNum); //Updates the year of all CD accounts
                            ((CD) e).setCurrentBalance();   //Updates the current accumulated balance of the CD account
                        }
                        System.out.println("");
                        e.printInfo();      //Print the information of all accounts in the accounts ArrayList
                    }
                    
                    //Adds one year to the year number
                    yearNum++;      
                    
                    System.out.println("\nOne year has passed and it is now the year " + yearNum);
                    
                    //Loops through every person in the people ArrayList
                    for(Person p : people){
                        if(p instanceof Customer)
                            //Adds one year all the customers' ages because a year has passed 
                            ((Customer) p).setAge(((Customer) p).getAge() + 1);
                    }
                    
                    //Calls the checkCDAccountMaturity method to check if any CD accounts have fully matured
                    accounts = checkCDAccountMaturity(accounts, yearNum);
                    
                    
                    displayMenu();     //Displays the menu
                    choice = scnr.nextLine(); //Stores the user's menu choice
                    
                    break;
                    
                //Makes a withdrawal
                case "4":
                    //Calls the accountWithdrawals method and updates the accounts ArrayList 
                    //in the main method by returning the edited accounts ArrayList 
                    accounts = accountWithdrawals(accounts);
                    
                    //Goes through all of the Account classes in the accounts ArrayList
                    for(Account e : accounts){
                        if(e instanceof CD){
                            ((CD) e).setCurrentYear(yearNum); //Updates the year of all CD accounts
                            ((CD) e).setCurrentBalance();   //Updates the current accumulated balance of the CD account
                        }
                    }
                    
                    //Adds one year to the year number
                    yearNum++;     
                    
                    System.out.println("\nOne year has passed and it is now the year " + yearNum);
                    
                    //Loops through every person in the people ArrayList
                    for(Person p : people){
                        if(p instanceof Customer)
                            //Adds one year all the customers' ages because a year has passed 
                            ((Customer) p).setAge(((Customer) p).getAge() + 1);
                    }
                    
                    //Calls the checkCDAccountMaturity method to check if any CD accounts have fully matured
                    accounts = checkCDAccountMaturity(accounts, yearNum);
                    
                    
                    displayMenu();  //Displays the menu
                    choice = scnr.nextLine(); //Stores the user's menu choice
                    break;
                    
                //Makes a deposit  
                case "5":
                    
                    //Calls the accountDeposits method and updates the the accounts ArrayList 
                    //in the main method by returning the edited accounts ArrayList 
                    accounts = accountDeposits(accounts);
                    
                    //Goes through all of the Account classes in the accounts ArrayList
                    for(Account e : accounts){
                        if(e instanceof CD){
                            ((CD) e).setCurrentYear(yearNum); //Updates the year of all CD accounts
                            ((CD) e).setCurrentBalance();   //Updates the current accumulated balance of the CD account
                        }
                    }
                    
                    //Adds one year to the year number
                    yearNum++;     
                    
                    System.out.println("\nOne year has passed and it is now the year " + yearNum);
                    
                    //Loops through every person in the people ArrayList
                    for(Person p : people){
                        if(p instanceof Customer)
                            //Adds one year all the customers' ages because a year has passed 
                            ((Customer) p).setAge(((Customer) p).getAge() + 1);
                    }
                    
                    //Calls the checkCDAccountMaturity method to check if any CD accounts have fully matured
                    accounts = checkCDAccountMaturity(accounts, yearNum);
                    
                    
                    displayMenu();  //Displays the menu
                    choice = scnr.nextLine(); //Stores the user's menu choice
                    break;
                
                //Shows information for all the accounts  
                case "6":
                    
                    //Only executes if the account is not empty
                    if(!accounts.isEmpty()){
                        //Goes through all of the Account classes in the accounts ArrayList
                        for(Account e : accounts){
                            if(e instanceof CD){
                                ((CD) e).setCurrentYear(yearNum); //Updates the year of all CD accounts
                                ((CD) e).setCurrentBalance();   //Updates the current accumulated balance of the CD account
                            }
                            System.out.println("");
                            e.printInfo();      //Print the information of all accounts in the accounts ArrayList
                        }
                    }
                    
                    //Executes if there are no accounts in the accounts ArrayList
                    else{
                        System.out.println("\nThere are currently no accounts in the system.");
                        System.out.println("Make one at the Fifth Third Bank of Wells-Fargos in America today!");
                    }     
                    
                    displayMenu();  //Displays the menu
                    choice = scnr.nextLine(); //Stores the user's menu choice
                    break;
                    
                //Creates a new customer
                case "7":
                    
                    //Calls the addCustomer method and adds the returned Customer object into the people ArrayList
                    people.add(addCustomer());
                    System.out.println("");
                    System.out.println("Customer added to the system!");
                    System.out.println("Thank you for choosing the Fifth Third Bank of Wells-Fargos in America!");
                    
                    System.out.println("\nHere are the people currently in the system.");
                    
                    //Print the information of all people in the people ArrayList
                    for(Person p : people){
                        System.out.println("");
                        p.printInfo();
                    }

                    //Goes through all of the Account classes in the accounts ArrayList
                    for(Account e : accounts){
                        if(e instanceof CD){
                            ((CD) e).setCurrentYear(yearNum); //Updates the year of all CD accounts
                            ((CD) e).setCurrentBalance();   //Updates the current accumulated balance of the CD account
                        }
                    }
                    
                    //Adds one year to the year number
                    yearNum++;     
                    
                    System.out.println("\nOne year has passed and it is now the year " + yearNum);
                    
                    //Loops through every person in the people ArrayList
                    for(Person p : people){
                        if(p instanceof Customer)
                            //Adds one year all the customers' ages because a year has passed 
                            ((Customer) p).setAge(((Customer) p).getAge() + 1);
                    }
                    
                    //Calls the checkCDAccountMaturity method to check if any CD accounts have fully matured
                    accounts = checkCDAccountMaturity(accounts, yearNum);
                    
                    
                    displayMenu();  //Displays the menu
                    choice = scnr.nextLine(); //Stores the user's menu choice
                    break;
                
                //Creates a new employee
                case "8":
                    
                    //Calls the addEmployee method and adds the returned Employee object to the people ArrayList
                    people.add(addEmployee());
                    System.out.println("");
                    System.out.println("Employee added into the system.");
                    System.out.println("Welcome to the Fifth Third Bank of Wells-Fargos"
                            + "\nin America workforce!");
                    
                    
                    System.out.println("\nHere are the people currently in the system.");
                    
                    for(Person p : people){
                        System.out.println("");
                        p.printInfo();
                        
                    }
                    
                    //Goes through all of the Account classes in the accounts ArrayList
                    for(Account e : accounts){
                        if(e instanceof CD){
                            ((CD) e).setCurrentYear(yearNum); //Updates the year of all CD accounts
                            ((CD) e).setCurrentBalance();   //Updates the current accumulated balance of the CD account
                        }
                    }
                    
                    //Adds one year to the year number
                    yearNum++;     
                    
                    System.out.println("\nOne year has passed and it is now the year " + yearNum);
                    
                    //Loops through every person in the people ArrayList
                    for(Person p : people){
                        if(p instanceof Customer)
                            //Adds one year all the customers' ages because a year has passed 
                            ((Customer) p).setAge(((Customer) p).getAge() + 1);
                    }
                    
                    //Calls the checkCDAccountMaturity method to check if any CD accounts have fully matured
                    accounts = checkCDAccountMaturity(accounts, yearNum);
                    
                    
                    displayMenu();  //Displays the menu
                    choice = scnr.nextLine(); //Stores the user's menu choice
                    break;
                
                //Makes one year pass
                case "9":
                    //Adds one year to the year number
                    yearNum++;
                    System.out.println("\nOne year has passed and it is now the year " + yearNum);
                    
                    //Goes through all of the Account classes in the accounts ArrayList
                    for(Account e : accounts){
                        if(e instanceof CD){
                            ((CD) e).setCurrentYear(yearNum); //Updates the year of all CD accounts
                            ((CD) e).setCurrentBalance();   //Updates the current accumulated balance of the CD account
                        }
                    }    
                    
                    
                    //Loops through every person in the people ArrayList
                    for(Person p : people){
                        if(p instanceof Customer)
                            //Adds one year all the customers' ages because a year has passed 
                            ((Customer) p).setAge(((Customer) p).getAge() + 1);
                    }
                    
                    //Calls the checkCDAccountMaturity method to check if any CD accounts have fully matured
                    accounts = checkCDAccountMaturity(accounts, yearNum);
                    
                    
                    displayMenu();  //Displays the menu
                    choice = scnr.nextLine(); //Stores the user's menu choice
                    break;
                    
                //Prints everyones information   
                case "10":
                    System.out.println("");
                    
                    //Only executes if the people ArrayList is not empty
                    if(!people.isEmpty()){
                        System.out.println("\nHere are the people currently in the system.");

                        for(Person p : people){
                            System.out.println("");
                            p.printInfo();      //Prints the person's information
                        }
                    
                    //Execute if there are is no one in the system    
                    }else{
                        System.out.println("There are currently no one in the system.");
                        System.out.println("Become a customer or an employee today!");
                    }
                    
                    displayMenu();  //Displays the menu
                    choice = scnr.nextLine(); //Stores the user's menu choice
                    break;
                    
                //Exits the program    
                case "0": 
                    System.out.println("\nExiting program....");
                    choice = "0";       //Sets choice to equal "0", making it break out of the while loop 
                                        //and ending the program
                    break;
                
                //Displays an error message for an invalid menu choice
                default:
                    System.out.println("\n" + choice + " is not a valid input.");
                    System.out.println("Please try again.");
                    displayMenu();  //Displays the menu
                    choice = scnr.nextLine(); //Allows the user to make a correct menu choice
            }
       
        }

    }
    
    /**
     * Displays the menu of the program.
     */
    public static void displayMenu(){
        System.out.println("");
        System.out.println("Please enter the action you would like to perform:");
        System.out.println("1. Create a new Checking account");
        System.out.println("2. Create a new Savings account");
        System.out.println("3. Create a new CD account");
        System.out.println("4. Make a withdrawal from one of my accounts");
        System.out.println("5. Make a deposit into one of my accounts");
        System.out.println("6. Print information for all of my accounts");
        System.out.println("7. Add a new customer");
        System.out.println("8. Add a new employee");
        System.out.println("9. Make one year pass");
        System.out.println("10. Print information for all people in the system");
        System.out.println("0. Exit the program");
        
    }
    
    /**
     * Creates a checking account object and returns it to be added into the ArrayList accounts
     * @param accounts The current ArrayList accounts 
     * @return The new checking account object
     */
    public static Account createCheckingAccount(ArrayList<Account> accounts){
        Scanner scnr = new Scanner(System.in);
        int PIN; //Stores the PIN number
        double balance; //Stores the account balance
        
        System.out.println("");
        System.out.println("Please enter the name of your new Checking account");
        String name = scnr.nextLine();  //Stores the name of the checking account
        
        //Continues to loop until all inputs are correct
        while(true){
        try{
            System.out.println("");
            System.out.println("Please enter a 4-digit PIN number for your new checking account \n" +
                                               "Make sure to remember it.");
            PIN = scnr.nextInt();
            
            //Throws an exception if the PIN is not 4 digits long
            if (Integer.toString(PIN).length()!= 4){
                throw new Exception("\nERROR!: Your PIN number must only include numbers and be 4 digits long \n"
                                    + "Please try again");
                            }
            
                            //Checks if the PIN is already being used for one of the accounts
                            for(Account e : accounts){
                                if (e.getPIN() == PIN)
                                    throw new Exception("\n The " + PIN + " PIN number is already being used for one of your accounts. "
                                            + "\nPlease enter another PIN");
                            }
                            break;      //Breaks out of the while loop, meaning the PIN means all requirements
                        }
        
                        //Catches an InputMismatchException if anything other than numbers is entered for the PIN
                        catch(InputMismatchException e){
                            //Displays an error message
                            System.out.println("\nERROR!: Your PIN number must only include numbers and be 4 digits long \n" +
                            "Please try again");
                            scnr.nextLine();
                        }catch(Exception e){
                            
                            //Displays the Exception error message if the PIN is not 4 digits long or is already
                            //used
                            System.out.println(e.getMessage());
                            scnr.nextLine();
                        }
                    }
                    
                    //Continues to loop until all inputs are correct
                    while(true){
                        try{
                            System.out.println("");
                            System.out.printf("How much would you like to deposit into your %s checking account? \n", name);
                            System.out.println("IMPORTANT!: You must deposit at least $25.00 to open a checking account");
                            System.out.print("$");
                            balance = scnr.nextDouble();
                            
                            //Throws an exception if the entered balance is less than $25
                            if(balance < 25)
                                throw new Exception("\nYou must deposit at least $25.00 to open a checking account\n"
                                        + "Please try again.");
                            
                            break; //Breaks out of the while loop
                            
                        //Catches an InputMismatchException if anything other than numbers is entered for the balance    
                        }catch(InputMismatchException e){
                            //Diplays the error message
                            System.out.println("\nYou can only enter numbers into your checking account balance.");
                            System.out.println("Please try again.");
                            scnr.nextLine();
                        }
                        catch(Exception e){
                            //Diplays the exception's error message if the the balance is lower than $25.00
                            System.out.println(e.getMessage());
                            scnr.nextLine();
                        }
                    }
                    //Returns the new Checking object
                    return new Checking(name, PIN, balance);
                    
                    
    }
    
    /**
     * Creates a Savings account object and returns it to be added into the ArrayList accounts
     * @param accounts The current ArrayList accounts 
     * @return The new savings account object 
     */
    public static Account createSavingsAccount(ArrayList<Account> accounts){
        Scanner scnr = new Scanner(System.in);
        int PIN;        //Holds the PIN
        double balance;     //Holds the balance
        
        System.out.println("");
        System.out.println("Please enter the name of your new Savings account");
        String name = scnr.nextLine(); //Holds the name of the account
        
        //Continues to loop until the inputs are correct
        while(true){
        try{
            System.out.println("");
            System.out.println("Please enter a 4-digit PIN number for your new Savings account \n" +
                                               "Make sure to remember it.");
            PIN = scnr.nextInt();
            
            //Throws an Exception if the PIN is not 4-digits long
            if (Integer.toString(PIN).length()!= 4){
                throw new Exception("\nERROR!: Your PIN number must only include numbers and be 4 digits long \n"
                                    + "Please try again");
                            }
                            
                            //Throws an Exception if the PIN is already being used in one of the accounts
                            for(Account e : accounts){
                                if (e.getPIN() == PIN)
                                    throw new Exception("\nThe " + PIN + " PIN number is already being used for one of your accounts. "
                                            + "\nPlease enter another PIN");
                            }
                            break; //Break out of the while loop
                        }
                        catch(InputMismatchException e){
                            System.out.println("\nERROR!: Your PIN number must only include numbers and be 4 digits long \n" +
                            "Please try again");
                            scnr.nextLine();
                        }catch(Exception e){
                            System.out.println(e.getMessage());
                            scnr.nextLine();
                        }
                    }
                    
                    //Continues to loop until the inputs are correct
                    while(true){
                        try{
                            System.out.println("");
                            System.out.printf("How much would you like to deposit into your %s savings account? \n", name);
                            System.out.println("IMPORTANT!: You must deposit at least $100.00 to open a savings account");
                            System.out.print("$");
                            balance = scnr.nextDouble();
                            
                            //Throws an Exception if the balance is less than $100.00
                            if(balance < 100)
                                throw new Exception("\nYou must deposit at least $100.00 to open a savings account\n"
                                        + "Please try again.");
                            
                            break; //Breaks out of the while loop
                            
                        }catch(InputMismatchException e){
                            System.out.println("\nYou can only enter numbers into your savings account balance.");
                            System.out.println("Please try again.");
                            scnr.nextLine();
                        }
                        catch(Exception e){
                            System.out.println(e.getMessage());
                            scnr.nextLine();
                        }
                    }
                    //Returns the new Savings account object
                    return new Savings(name, PIN, balance);
                    
                    
    }
    
    /**
     * Creates a CD account object and returns it to be added into the ArrayList accounts
     * @param accounts  The current ArrayList accounts 
     * @param yearNum   The current year number
     * @return The new CD account object
     */
    public static Account createCDAccount(ArrayList<Account> accounts, int yearNum){
        Scanner scnr = new Scanner(System.in);
        int PIN;
        double balance;
        
        System.out.println("");
        System.out.println("Please enter the name of your new CD account");
        String name = scnr.nextLine();
                   
        while(true){
        try{
            System.out.println("");
            System.out.println("Please enter a 4-digit PIN number for your new CD account \n" +
                                               "Make sure to remember it.");
            PIN = scnr.nextInt();
            
            //Throws an Exception if the PIN number is not 4 digits long
            if (Integer.toString(PIN).length()!= 4){
                throw new Exception("\nERROR!: Your PIN number must only include numbers and be 4 digits long \n"
                                    + "Please try again");
                            }
                            
                            //Throws an Exception if the PIN number is already being used for one of the accounts
                            for(Account e : accounts){
                                if (e.getPIN() == PIN)
                                    throw new Exception("\nThe " + PIN + " PIN number is already being used for one of your accounts. "
                                            + "\nPlease enter another PIN");
                            }
                            break;
                        }
                        catch(InputMismatchException e){
                            System.out.println("\nERROR!: Your PIN number must only include numbers and be 4 digits long \n" +
                            "Please try again");
                            scnr.nextLine();
                        }catch(Exception e){
                            System.out.println(e.getMessage());
                            scnr.nextLine();
                        }
                    }

                    while(true){
                        try{
                            System.out.println("");
                            System.out.printf("How much would you like to deposit into your %s CD account?", name);
                            System.out.println("\nNOTE: Fifth Third Bank of Wells-Fargos in America CD accounts"
                                    + "\nhave a .03% APY that is compounded monthly and held for 3 years");
                            System.out.print("$");
                            balance = scnr.nextDouble();
                            
                            //Throws an Exception if the balance is less than $500.00
                            if(balance < 500)
                                throw new Exception("\nYou must deposit at least $500.00 to open a CD account\n"
                                        + "Please try again.");
                            
                            break;
                            
                        }catch(InputMismatchException e){
                            System.out.println("\nYou can only enter numbers into your CD account balance.");
                            System.out.println("Please try again.");
                            scnr.nextLine();
                        }
                        catch(Exception e){
                            System.out.println(e.getMessage());
                            scnr.nextLine();
                        }
                    }
                    
                    
                    //Created and return a new CD account object
                    return new CD(name, PIN, balance, yearNum);
        
    }
   
    /**
    * Checks if any of the CD accounts have matured.
    * @param accounts  The current ArrayList accounts 
    * @param yearNum   The current year number
    * @return The updated accounts ArrayList
    */
    public static ArrayList<Account> checkCDAccountMaturity(ArrayList<Account> accounts, int yearNum) {
        
        //Stores the CD accounts to be removed
        ArrayList<Account> CDsToBeRemoved = new ArrayList<Account>();
        
        //Loops through all the accounts
        for(Account e : accounts){
            if(e instanceof CD){    //Check if the current account is a CD account
                if(((CD) e).getMaturityYear() == yearNum){  //Check if the CD account's maturity year has been reached
                    System.out.println("\nYour " + e.getNameOfAccount() + " CD account has fully matured!");
                    System.out.printf("A $%,.2f check will be sent to you in the mail in 3-5 business days\n",e.getBalance());
                    System.out.println("Your " + e.getNameOfAccount() + " CD account will now be removed from the system.");
                    CDsToBeRemoved.add(e);      //Adds the CD account to be removed.
                }
            }
        }
        
        accounts.removeAll(CDsToBeRemoved);     //Removes the CD account
        
        return accounts;        //Returns the updated accounts ArrayList
    }
    
    /**
     * Allows a withdrawal from an account
     * @param accounts The current ArrayList accounts
     * @return The updated accounts ArrayList
     */
    public static ArrayList<Account> accountWithdrawals(ArrayList<Account> accounts){
        Scanner scnr = new Scanner(System.in);
        int PIN;
        boolean pinExists = false;      //Used to check if the PIN exists within the accounts
        
        //Executes if the accounts ArrayList is not empty
        if(!accounts.isEmpty()){
            while(true){
                try{
                    System.out.println("\nPlease enter the 4-digit PIN number of the account you wish to withdraw from: ");
                    PIN = scnr.nextInt();
                    
                    //Throws an Exception if the PIN is not 4-digits long
                    if(Integer.toString(PIN).length()!= 4)
                        throw new Exception("\nYour PIN number must 4-digits long and can only contain numbers");
                    
                    for(Account e : accounts){
                        if(e.getPIN() == PIN)
                            pinExists = true;   //If the PIN number is found in one of the accounts, pinExists equals true
                    }
                    
                    //Throws an Exception if the PIN is not seen in the accounts ArrayList
                    if(!pinExists){
                        throw new Exception("\nThis PIN number does not exist within the system."
                                + "\nPlease try again.");
                    }
                    break;
                }catch(InputMismatchException e){
                    System.out.println("\nA PIN number must 4-digits long and can only contain numbers");
                    System.out.println("Please try again!");
                    scnr.nextLine();
                }catch(Exception e){
                    System.out.println(e.getMessage());
                    scnr.nextLine();
                } 
            }
                        
            while(true){
                try{
                    for(Account e : accounts){
                        if(e.getPIN() == PIN){
                            //Money cannot be withdrawn from a CD account, so the method ends
                            if(e instanceof CD){
                                System.out.println("\nThis PIN number is for a CD account.");
                                e.withdrawal(0);    //Error message displayed in CD withdrawal method
                                break;
                            }
                            
                            System.out.println("");           
                            e.printInfo();      //Prints the account with the matching PIN number
                            System.out.println("Please enter the amount of money you wish to withdraw from this account");
                            System.out.print("$");
                            double amount = scnr.nextDouble();
                                        
                            e.withdrawal(amount);       //Call the accounts withdrawal method
                        }
                    }
                break;
                }catch(InputMismatchException e){
                    System.out.println("\nYou can only enter numbers for the amount you wish to withdrawal");
                    scnr.nextLine();
                }
            } 
        //Executes if there are no accounts in the accounts ArrayList    
        }else{
            System.out.println("\nThere are currently no accounts to withdraw from in the system.");
            System.out.println("Make one at the Fifth Third Bank of Wells-Fargos in America today!");
            }
        
        //Returns the updated accounts ArrayList
        return accounts;
    }
    
    /**
     * Allows deposits from an account
     * @param accounts The current ArrayList accounts
     * @return The updated accounts ArrayList
     */
    public static ArrayList<Account> accountDeposits(ArrayList<Account> accounts){
        Scanner scnr = new Scanner(System.in);
        int PIN;
        boolean pinExists = false;
        
        if(!accounts.isEmpty()){
            while(true){
                try{
                    System.out.println("\nPlease enter the 4-digit PIN number of the account you wish to deposit into: ");
                    PIN = scnr.nextInt();
                    
                    //Throws an Exception if the PIN is not 4-digits long
                    if(Integer.toString(PIN).length()!= 4)
                        throw new Exception("\nYour PIN number must 4-digits long and can only contain numbers");
                    
                    for(Account e : accounts){
                        if(e.getPIN() == PIN)
                            pinExists = true;   //If one of the PIN number matches one of the accounts' PIN, pinExists is true 
                    }
                    
                    //Throws an Exception the PIN does not match any other PIN in the system.
                    if(!pinExists){
                        throw new Exception("\nThis PIN number does not exist within the system."
                                + "\nPlease try again.");
                    }
                    break;
                }catch(InputMismatchException e){
                    System.out.println("\nA PIN number must 4-digits long and can only contain numbers");
                    System.out.println("Please try again!");
                    scnr.nextLine();
                }catch(Exception e){
                    System.out.println(e.getMessage());
                    scnr.nextLine();
                } 
            }
                        
            while(true){
                try{
                    for(Account e : accounts){
                        if(e.getPIN() == PIN){
                            //Money cannot be deposit into a CD, so the method ends if the PIN is for a CD account
                            if(e instanceof CD){
                                System.out.println("\nThis PIN number is for a CD account.");
                                e.deposit(0);
                                break;
                            }
                            
                            System.out.println("");           
                            e.printInfo();      //Prints the accounts information
                            System.out.println("Please enter the amount of money you wish to deposit into this account");
                            System.out.print("$");
                            double amount = scnr.nextDouble();
                                        
                            e.deposit(amount); //Call the accounts' deposit method
                        }
                    }
                break;
                }catch(InputMismatchException e){
                    System.out.println("\nYou can only enter numbers for the amount you wish to deposit");
                    scnr.nextLine();
                }
            }
        //Executes if there are no accounts in the accounts ArrayList
        }else{
            System.out.println("\nThere are currently no accounts to deposit into in the system.");
            System.out.println("Make one at the Fifth Third Bank of Wells-Fargos in America today!");
            }
        //Returns the updated accounts ArrayList
        return accounts;
        
    }
    
    /**
     * Creates and returns a Customer object
     * @return the new Customer object
     */
    private static Person addCustomer() {
        Scanner scnr = new Scanner(System.in);
        String name, address, email; 
        int age;
        
        System.out.println("\nHello, new Fifth Third Bank of Wells-Fargos in America customer!");
        System.out.println("What is your name?");
        name = scnr.nextLine();
        
        System.out.println("\nWhat is your address?");
        address = scnr.nextLine();
        
        System.out.println("\nWhat is your email?");
        email = scnr.nextLine();
        
        while(true){
            try{
                System.out.println("\nHow old are you?");
                age = scnr.nextInt();
                break;
                
            }catch(Exception e){
                System.out.println("\nYour age can only include integer numbers");
                System.out.println("Please try again.");
                scnr.nextLine();
            }
        }
        
        //Returns the new Customer object
        return new Customer(name, address, email, age);
        
    }
    
    /**
     * Creates and returns an Employee object
     * @return the new Employee object
     */
    private static Person addEmployee() {
        
        Scanner scnr = new Scanner(System.in);
        String name, address, email, position = "";
        int hoursWorked = 0;
        double payRate = 0.00;
        
        System.out.println("\nHello, new Fifth Third Bank of Wells-Fargos in America employee!");
        System.out.println("What is your name?");
        name = scnr.nextLine();
        
        System.out.println("\nWhat is your address?");
        address = scnr.nextLine();
        
        System.out.println("\nWhat is your email?");
        email = scnr.nextLine();
        
        //Allows the user to choice what position they want in the bank
        while(true){
            System.out.println("\nPlease select what your position in the company is: ");
            System.out.println("1. Banker (Pay Rate: $20.50/hr)");
            System.out.println("2. Teller (Pay Rate: $13.75/hr)");
            System.out.println("3. Finanical Center Manager(Pay Rate: $29.50/hr)");
            String choice = scnr.nextLine();
            
                if(choice.equals("1")) {
                    position = "Banker"; //Sets the position to "Banker" if the user selects 1
                    payRate = 20.50;    //Sets the payRate if the user selects 1
                    break;
                }else if(choice.equals("2")){
                    position = "Teller";    //Sets the position to "Teller" if the user selects 2
                    payRate = 13.75;        //Sets the payRate if the user selects 2
                    break;
                }else if(choice.equals("3")){
                    position = "Finanical Center Manager";      //Sets the position to "Finanical Center Manager" if the user selects 3
                    payRate = 29.50;        //Sets the payRate if the user selects 3
                    break;
                    
                //Displays an error message if they do not make a valid selection
                }else{
                    System.out.println(choice + " is not a valid selection.");
                    System.out.println("Please try again!");
                    break;  
                }
            
        }
        
        while(true){
            try{
                System.out.println("\nHow many hours have you worked this month?");
                hoursWorked = scnr.nextInt();
                break;
                
            }catch(Exception e){
                System.out.println("\nThe number of hours you have worked this month can only include integer numbers");
                System.out.println("Please try again.");
                scnr.nextLine();
            }
        }
        
        //Returns the new Employee object
        return new Employee(name, address, email, position, hoursWorked, payRate);
    }
}