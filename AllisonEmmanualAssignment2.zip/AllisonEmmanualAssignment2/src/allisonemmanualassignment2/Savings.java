/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package allisonemmanualassignment2;

import java.util.Scanner;

/**
 *
 * @author Emmanual Allison
 */
public class Savings extends Account {
    private int numOfWithdrawals = 0; //Holds the number of withdrawals
    
    /**
     * Constructor
     * @param nameOfAccount
     * @param PIN
     * @param initialBalance 
     */
    public Savings(String nameOfAccount, int PIN, double initialBalance) {
        super(nameOfAccount, PIN, initialBalance);
    }
    
/**
 * Allows money to removed from an account and increments the number of withdrawal
 * After 5 withdrawals have occurred from the account, an error message will be displayed 
 * that will give the user the option to continue with the withdrawal with a $5.00 fee applied for each 
 * withdrawal after or cancel the transaction. The transaction will also be cancel if the amount they wish
 * to withdraw is great than their balance.
 * @param amount Money to be withdrawn
 */    
    @Override
    public void withdrawal(double amount){
        Scanner scnr = new Scanner (System.in);
        String choice;
        
        //Cancels the transaction if the the amount they wish
        //to withdraw is great than their balance.
        if(amount > super.getBalance()){
            System.out.println("");
            System.out.printf("Only $%,.2f are available in your account\n"
                            + "The $%,.2f you wish to withdraw is greater than your current balance in your %s savings account\n", 
                    super.getBalance(), amount, super.getNameOfAccount());
            System.out.println("\nWithdrawal canceled.");
            return; //Returns to the main method
        }
        
        //No fee is incured if the number of withdrawals is less than 6
        if(numOfWithdrawals < 6){
            super.setBalance(super.getBalance()- amount);
            System.out.println("\nWithdrawal completed.");
            System.out.printf("\nYou now have have $%,.2f in your %s Savings account.\n", super.getBalance(), super.getNameOfAccount());
            System.out.println("\nThank you for banking at Fifth Third Bank of Wells-Fargos \n" + 
                           "in America!");
            numOfWithdrawals++;
            return;
        }
        
        //Gives the choice if the the user would like to cancel or continue with the $5.00 fee applied
        if (numOfWithdrawals >= 6){
            System.out.println("\nTo incentivize our customers to budget their spending and\n" + 
                               "save money, the Fifth Third Bank of Wells-Fargos in America\n" + 
                               "allows 5 withdrawals from a savings account before\n" + 
                               "applying a $5.00 overuse fee taken from said savings account.\n"+
                               "If you choose to choose to continue with this transaction,\n" +
                               "a $5.00 fee will be applied to this withdrawal and the rest\n" +
                               "of the withdrawals from this savings account.\n");
            
            System.out.println("Would you like to continue with this withdrawal?");
            System.out.println("Please enter \"YES\" or \"NO\"");
            choice = scnr.nextLine();
            
            //Error message if the user does not type "yes" or "no"
            while(!choice.equalsIgnoreCase("YES") && !choice.equalsIgnoreCase("NO")){
                System.out.println("\n" + choice + " is not a valid entry! Please try again");
                System.out.println("\nWould you like to continue with this withdrawal?");
                System.out.println("Please enter \"Y\" for YES or \"N\" for NO");
                choice = scnr.nextLine();
            }
            
            //Transation continues with fee applied
            if(choice.equalsIgnoreCase("YES")){
                super.setBalance(super.getBalance()- amount - 5.00);
                System.out.printf("\n$%,.2f withdrawal completed with $5.00 overuse fee applied", amount);
                System.out.printf("\nYou now have $%,.2f in your %s savings account", super.getBalance(), super.getNameOfAccount());
                System.out.println("");
                numOfWithdrawals++;
            }
            
            //Transation is canceled
            if(choice.equalsIgnoreCase("NO")){
                System.out.println("\nWithdrawal canceled.");
            }
        }
        
    }

    /**
     * Adds the amount into the saving account balance.
     * @param amount Money to be deposited
     */
    @Override
    public void deposit(double amount){
        super.setBalance(super.getBalance()+ amount);
        System.out.printf("\n$%,.2f have been deposited into your %s savings account.\n", amount, super.getNameOfAccount());
        System.out.printf("\nThere is now $%,.2f available in your %s savings account.\n", super.getBalance(), super.getNameOfAccount());
        System.out.println("Thank you for banking at Fifth Third Bank of Wells-Fargos \n" + 
                           "in America!");
    }
    
    /**
     * Prints the information of the savings account.
     */
    @Override
    public void printInfo(){
        System.out.println("Account Type: SAVINGS");
        super.printInfo();
        System.out.println("Number of withdrawals: " + numOfWithdrawals);
        System.out.println("***********************************");
    }
}
