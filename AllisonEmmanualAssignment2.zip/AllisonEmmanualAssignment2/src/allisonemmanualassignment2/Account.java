/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package allisonemmanualassignment2;
import java.util.Random;
/**
 *
 * @author Emmanual Allison
 */
public abstract class Account {
    private String nameOfAccount;       //Stores the name of the account
    private int PIN;                    //Stores the PIN number
    private double balance = 0.00;      //Stores the balance
    private String accountID = "";      //Stores the account ID

    /**
     * Constructor
     * @param nameOfAccount
     * @param PIN
     * @param initialBalance 
     */
    public Account(String nameOfAccount, int PIN, double initialBalance) {
        Random rnd = new Random();
        this.nameOfAccount = nameOfAccount;
        this.PIN = PIN;
        this.balance = initialBalance;
     
        //Genterates a random number from zero to nine, turns said number into
        //a string that in accumulated into the account ID field to create a
        //sixteen digit long accountID of random numbers
        for(int i = 0; i < 16; i++)
           this.accountID += Integer.toString(rnd.nextInt(9));
    }

    /**
     * Getter for the name of the account
     * @return the name of the account
     */
    public String getNameOfAccount() {
        return nameOfAccount;
    }

    /**
     * Setter for the name of the account
     * @param nameOfAccount 
     */
    public void setNameOfAccount(String nameOfAccount) {
        this.nameOfAccount = nameOfAccount;
    }

    /**
     * Gets the balance
     * @return The account balance
     */
    public double getBalance() {
        return balance;
    }

    /**
     * Sets the balance of the account
     * @param balance 
     */
    public void setBalance(double balance) {
        this.balance = balance;
    }

    /**
     * Sets the PIN of the account
     * @param PIN 
     */
    public void setPIN(int PIN) {
        this.PIN = PIN;
    }
    
    /**
     * Gets the PIN of the account
     * @return The account PIN number
     */
    public int getPIN(){
        return PIN;
    }

    /**
     * Gets the account ID
     * @return The account ID
     */
    public String getAccountID() {
        return accountID;
    }

    /**
     * Allows money to be removed from an account balance
     * @param amount 
     */
    public abstract void withdrawal(double amount);
    
    /**
     * Allows money to be added into an account balance
     * @param amount 
     */
    public abstract void deposit(double amount);

    /**
     * Prints the account name, account number, and the current balance
     */
    public void printInfo(){
       System.out.printf("Name of Account: %s\n", nameOfAccount);
       System.out.printf("Account Number: %s\n", accountID);
       System.out.printf("Current Balance: $%,.2f\n", balance);
   }
}
