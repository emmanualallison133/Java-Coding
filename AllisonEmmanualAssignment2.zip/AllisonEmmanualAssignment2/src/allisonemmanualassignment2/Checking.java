/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package allisonemmanualassignment2;

/**
 *
 * @author Emmanual Allison
 */
public class Checking extends Account {
    
    /**
     * Constructor
     * @param nameOfAccount
     * @param PIN
     * @param initialBalance 
     */
    public Checking(String nameOfAccount, int PIN, double initialBalance) {
        super(nameOfAccount, PIN, initialBalance);
    }
    
    /**
     * Allows money to be removed from the checking account. If the amount is
     * larger than the balance then the transaction is canceled.
     * @param amount Money to be withdrawn
     */
    @Override
    public void withdrawal(double amount){
        if(amount > super.getBalance()){
            System.out.println("");
            System.out.printf("Only $%,.2f are available in your account\n"
                            + "The $%,.2f you wish to withdraw is greater than your current \n"
                    +         "balance in your %s checking account\n", 
                    super.getBalance(), amount, super.getNameOfAccount());
            System.out.println("\nWithdrawal canceled.");
            return;
        }
        
        super.setBalance(super.getBalance()- amount);
            System.out.println("\nWithdrawal completed.");
            System.out.printf("\nYou now have have $%,.2f in your %s Checking account.\n", super.getBalance(), super.getNameOfAccount());
            System.out.println("Thank you for banking at Fifth Third Bank of Wells-Fargos \n" + 
                           "in America!");
    }
    
    /**
     * Allow money to be added into an account.
     * @param amount Money to be deposited
     */
    @Override
    public void deposit(double amount){
        super.setBalance(super.getBalance()+ amount);
        System.out.printf("\n$%,.2f have been deposited into your %s Checking account.\n", amount, super.getNameOfAccount());
        System.out.printf("\nThere is now $%,.2f available in your %s Checking account.\n", super.getBalance(), super.getNameOfAccount());
        System.out.println("Thank you for banking at Fifth Third Bank of Wells-Fargos \n" + 
                           "in America!");
    }
    
    /**
     * Prints all information on the checking account
     */
    @Override
    public void printInfo(){
        System.out.println("\nAccount Type: CHECKING");
        super.printInfo();
        System.out.println("***********************************");
    }
}
