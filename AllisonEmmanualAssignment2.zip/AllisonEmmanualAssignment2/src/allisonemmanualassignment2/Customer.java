/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package allisonemmanualassignment2;

/**
 *
 * @author Emmanual Allison
 */
public class Customer extends Person{
    private int age; //Holds the customer's age
    
    /**
     * Constructor for the Customer class, which extends the abstract Person class
     * @param name Holds the customer's name
     * @param address Holds the customer's address
     * @param email Holds the customer's  email
     * @param age Holds the customer's age
     */
    public Customer(String name, String address, String email, int age) {
        super(name, address, email); //Sends the name, address, email parameters into the constructor of the Person class
        this.age = age; //Assigns the age parameter to the object's age field
    }

    /**
     * Getter for the customer's age
     * @return The customer's age
     */
    public int getAge() {
        return age;
    }

    /**
     * Setter for the customer's age
     * @param age The age to be set
     */
    public void setAge(int age) {
        this.age = age;
    }
   
    @Override
    /**
     * Prints the Person type, the information stored in the abstract 
     * Person superclass's printInfo() method, and the customer's age.
     * Overrides the Person superclass.
     */
    public void printInfo(){
        System.out.println("Person Type: CUSTOMER");
        super.printInfo();
        System.out.println("Age: " + age);
        System.out.println("******************************************************************");
    }
}
