/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package allisonemmanualassignment2;

import java.util.Random;

/**
 *
 * @author Emmanual Allison
 */
public class Employee extends Person{
    private String workerID = "";   //Holds the worker's ID number
    private int hoursWorked;    //Holds how many hours the worker has worked
    private double payRate;     //Holds the worker's pay rate based on their position in the bank
    private String position;    //Hold the worker's position in the bank

    /**
     * Constructor for the Employee class
     * @param name      The employee's name
     * @param address   The employee's address
     * @param email     The employee's email
     * @param position  The employee's position
     * @param hoursWorked   The employee's hoursWorked
     * @param payRate   The employee's payRate
     */
    public Employee(String name, String address, String email, String position, int hoursWorked, double payRate) {
        super(name, address, email); //Sends the name, address, email parameters into the constructor of the Person class
        
        this.position = position; //Assigns the position parameter to be stored in the Employee class' position field
        
        Random rnd = new Random(); //Allows the use of random number generation
        
        this.hoursWorked = hoursWorked; //Assigns the hoursWorked parameter to be stored in the Employee class' hoursWorked field
        this.payRate = payRate; //Assigns the payRate parameter to be stored in the Employee class' payRate field
        
        //Generates an seven digit Employee ID by generating a random int number from 0 to 9, 
        //turning the number into a string, with is accumulated into the workerID field seven times.
        for(int i = 0; i < 7; i++){
            this.workerID += Integer.toString(rnd.nextInt(9)); 
        }
    }

    /**
     * Getter for the employee's position in the bank
     * @return The employee's position in the bank
     */
    public String getPosition() {
        return position;
    }

    /**
     * Getter for the employee's worker ID
     * @return the employee's worker ID
     */
    public String getWorkerID() {
        return workerID;
    }
    
    /**
     * Getter for how many hours that the employee worked
     * @return The number of hours the employee worked
     */
    public int getHoursWorked() {
        return hoursWorked;
    }

    /**
     * Setter for the number of hours that the employee worked
     * @param hoursWorked The number of hours to be set
     */
    public void setHoursWorked(int hoursWorked) {
        this.hoursWorked = hoursWorked;
    }

    /**
     * Gets the pay rate of the employee
     * @return The employee's pay rate
     */
    public double getPayRate() {
        return payRate;
    }

    @Override
    /**
     * Shows the person type, worker ID, the information stored in the Person superclass printInfo() method, 
     * the employee's position in the company, their pay rate, how many hours they've worked for the month, 
     * and their monthly pay when taxes are removed.
     * 
     * Overrides the printInfo() method in the Person superclass.
     */
    public void printInfo() {
        System.out.println("Person Type: EMPLOYEE");
        System.out.println("Worker ID: " + workerID);
        super.printInfo();
        System.out.println("Position: " + position);
        System.out.printf("Pay Rate: $%,.2f/hr\n", payRate);
        System.out.println("Hours Worked this month: " + hoursWorked + " hours");
        System.out.printf("Your monthly pay when 5.499%% is removed for taxes is $%,.2f\n",(payRate * hoursWorked)-(payRate * hoursWorked *.05499));
        System.out.println("******************************************************************");
    }
    
}
